@include('frontend.rcms.layout.header')
@yield('rcms_container')
@include('frontend.layout.footer')
