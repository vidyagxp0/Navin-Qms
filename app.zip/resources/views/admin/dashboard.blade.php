@php
    $mainmenu="Dashboard";
    $submenu="Dashboard";

@endphp
@extends('admin.layout')

@section('container')
  <!-- Small boxes (Stat box) -->
  <div class="row">



    <!-- ./col -->
  </div>
  <!-- /.row -->



@endsection


@section('jquery')



@endsection
