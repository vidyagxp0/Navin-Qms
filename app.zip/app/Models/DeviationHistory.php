<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DeviationHistory extends Model
{
    use HasFactory;
    protected $table = 'deviation_histories';

}
