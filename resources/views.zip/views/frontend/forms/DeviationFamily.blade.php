<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>VidyaGxP - Software</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>

<style>
    body {
        font-family: 'Roboto', sans-serif;
        margin: 0;
        padding: 0;
        min-height: 100vh;
    }

    .w-10 {
        width: 10%;
    }

    .w-20 {
        width: 20%;
    }

    .w-25 {
        width: 25%;
    }

    .w-30 {
        width: 30%;
    }

    .w-40 {
        width: 40%;
    }

    .w-50 {
        width: 50%;
    }

    .w-60 {
        width: 60%;
    }

    .w-70 {
        width: 70%;
    }

    .w-80 {
        width: 80%;
    }

    .w-90 {
        width: 90%;
    }

    .w-100 {
        width: 100%;
    }

    .h-100 {
        height: 100%;
    }

    header table,
    header th,
    header td,
    footer table,
    footer th,
    footer td,
    .border-table table,
    .border-table th,
    .border-table td {
        border: 1px solid black;
        border-collapse: collapse;
        font-size: 0.9rem;
        vertical-align: middle;
    }

    table {
        width: 100%;
    }

    th,
    td {
        padding: 10px;
        text-align: left;
    }

    footer .head,
    header .head {
        text-align: center;
        font-weight: bold;
        font-size: 1.2rem;
    }

    @page {
        size: A4;
        margin-top: 160px;
        margin-bottom: 60px;
    }

    header {
        position: fixed;
        top: -140px;
        left: 0;
        width: 100%;
        display: block;
    }
    
    footer {
        width: 100%;
        position: fixed;
        display: block;
        bottom: -40px;
        left: 0;
        font-size: 0.9rem;
    }

    footer td {
        text-align: center;
    }

    .inner-block {
        padding: 10px;
    }

    .inner-block tr {
        font-size: 0.8rem;
    }

    .inner-block .block {
        margin-bottom: 30px;
    }

    .inner-block .block-head {
        font-weight: bold;
        font-size: 1.1rem;
        padding-bottom: 5px;
        border-bottom: 2px solid #4274da;
        margin-bottom: 10px;
        color: #4274da;
    }
    .block-child {
        font-weight: bold;
        font-size: 1.1rem;
        padding-bottom: 5px;
        border-bottom: 2px solid #4274da;
        margin-bottom: 10px;
        color: #de4b23;
        text-align:center;
    }
    .sub-child{
        font-weight: bold;
        color: #de4b23;
        
    }


    .inner-block th,
    .inner-block td {
        vertical-align: baseline;
    }

    .table_bg {
        background: #4274da57;
    }
</style>

<body>

    <header>
        <table>
            <tr>
                <td class="w-70 head">
                    Deviation Family Report
                </td>
                <td class="w-30">
                    <div class="logo">
                        <img src="https://navin.mydemosoftware.com/public/user/images/logo.png" alt="" class="w-100">
                    </div>
                </td>
            </tr>
        </table>
        <table>
            <tr>
                <td class="w-30">
                    <strong> Deviation No.</strong>
                </td>
                <td class="w-40">
                   {{ Helpers::divisionNameForQMS($data->division_id) }}/{{ Helpers::year($data->created_at) }}/{{ str_pad($data->record, 4, '0', STR_PAD_LEFT) }}
                </td>
                <td class="w-30">
                    <strong>Record No.</strong> {{ str_pad($data->record, 4, '0', STR_PAD_LEFT) }}
                </td>
            </tr>
        </table>
    </header>

    <div class="inner-block">
        <div class="content-table">
            <div class="block">
                <div class="block-head">
                    General Information
                </div>
                <table>
                    <tr>  {{ $data->created_at }} added by {{ $data->originator }}
                        <th class="w-20">Site/Location Code</th>
                        <td class="w-30"> {{ Helpers::getDivisionName(session()->get('division')) }}</td>
                        <th class="w-20">Initiator</th>
                        <td class="w-30">{{ Helpers::getInitiatorName($data->initiator_id) }}</td>
                        </td>
                    </tr>
                    <tr>
                        <th class="w-20">Date of Initiation</th>
                        {{-- <td class="w-30">@if{{ Helpers::getdateFormat($data->intiation_date) }} @else Not Applicable @endif</td> --}}
                        {{-- <td class="w-30">@if (Helpers::getdateFormat($data->initiation_date)) {{ Helpers::getdateFormat($data->initiation_date) }} @else Not Applicable @endif</td> --}}
                        <td class="w-30"> {{  $data->created_at ? $data->created_at->format('d-M-Y') : 'Not Applicable' }} </td>

                        <th class="w-20">Due Date</th>
                        <td class="w-30"> @if($data->due_date){{ $data->due_date }} @else Not Applicable @endif</td>
                        
                    </tr>
                    <tr>
                        <th class="w-20">Department</th>    
                        <td class="w-30">  @if($data->Initiator_Group){{ Helpers::getInitiatorGroupFullName($data->Initiator_Group) }} @else Not Applicable @endif</td>
                        <th class="w-20">Department Code</th>
                        <td class="w-30">@if($data->initiator_group_code){{ $data->initiator_group_code }} @else Not Applicable @endif</td>
                    </tr>
                    <tr>
                        <th class="w-20">Short Description</th>
                        <td class="w-30"> @if($data->short_description){{ $data->short_description }}@else Not Applicable @endif</td>
                        <th class="w-20"> Nature of Repeat?</th>
                        <td class="w-30">@if($data->short_description_required){{ $data->short_description_required }} @else Not Applicable @endif</td>

                    </tr>
                    <tr>
                        <th class="w-20"> Repeat Nature</th>
                        <td class="w-30">@if($data->nature_of_repeat){{ $data->nature_of_repeat }} @else Not Applicable @endif</td>
                        <th class="w-20"> Deviation Observed On</th>
                        <td class="w-30">@if($data->Deviation_date){{ $data->Deviation_date }} @else Not Applicable @endif</td>
                    </tr>
                    <tr>
                        <th class="w-20"> Deviation Observed On (Time)</th>
                        <td class="w-30">@if($data->deviation_time){{ $data->deviation_time }} @else Not Applicable @endif</td>
                        <th class="w-20">Deviation Observed by</th>
                        @php
                        $facilityIds = explode(',', $data->Facility);
                        $users = $facilityIds ? DB::table('users')->whereIn('id', $facilityIds)->get() : [];
                    @endphp
                    
                    <td>
                        @if($facilityIds && count($users) > 0)
                            @foreach ($users as $user)
                                <option value="{{ $user->id }}" selected>{{ $user->name }}</option>
                            @endforeach
                        @else
                            Not Applicable
                        @endif
                    </td>
                    
                        {{-- <td class="w-30">@if($data->Facility){{ $data->Facility }} @else Not Applicable @endif</td> --}}
                        
                    </tr>
                    <tr>
                        <th class="w-20">Deviation Reported On </th>
                        <td class="w-30">@if($data->Deviation_reported_date){{ $data->Deviation_reported_date }} @else Not Applicable @endif</td>
                        <th class="w-20">Deviation Related To</th>
                        <td class="w-30">@if($data->audit_type){{ $data->audit_type }} @else Not Applicable @endif</td>
                    </tr>
                    <tr>
                       
                        <th class="w-20"> Others</th>
                        <td class="w-30">@if($data->others){{ $data->others }}@else Not Applicable @endif</td>                       
                    </tr>
                    <tr>
            
                            <th class="w-20">Facility/ Equipment/ Instrument/ System Details Required?</th>
                            <td class="w-30">@if($data->Facility_Equipment){{ $data->Facility_Equipment }}@else Not Applicable @endif</td>
                            <th class="w-20">Document Details Required?</th>
                            <td class="w-30">@if($data->Document_Details_Required){{ $data->Document_Details_Required }}@else Not Applicable @endif</td>


                    </tr>


                    <tr>
                        <th class="w-20">Name of Product & Batch No</th>
                        <td class="w-30">@if($data->Product_Batch){{ ($data->Product_Batch) }} @else Not Applicable @endif</td>
                        <th class="w-20">Description of Deviation</th>
                        <td class="w-30">@if($data->Description_Deviation){{ $data->Description_Deviation }} @else Not Applicable @endif</td>
                    </tr>
                    <tr>
                       
                        
                    </tr>
                    <tr>
                        <th class="w-20">Immediate Action (if any)</th>
                        <td class="w-30">@if($data->Immediate_Action){{ $data->Immediate_Action }}@else Not Applicable @endif</td>
                        <th class="w-20">Preliminary Impact of Deviation</th>
                        <td class="w-30">@if($data->Preliminary_Impact){{ $data->Preliminary_Impact }}@else Not Applicable @endif</td>
                    </tr>
                    
                </table>  
                    <div class="block">
                        <div class="block-head">
                            Facility/ Equipment/ Instrument/ System Details 
                        </div>
                        <div class="border-table">
                            <table>
                                <tr class="table_bg">
                                <th class="w-25">SR no.</th>
                                    <th class="w-25">Name</th>
                                    <th class="w-25">ID Number</th>
                                    <th class="w-25">Remarks</th>
                                
                                </tr>
                                @if(!empty($grid_data->IDnumber))
                                @foreach (unserialize($grid_data->IDnumber) as $key => $dataDemo)
                                <tr>
                                    <td class="w-15">{{ $dataDemo ? $key + 1  : "Not Applicable" }}</td>
                                    <td class="w-15">{{ unserialize($grid_data->facility_name)[$key] ?  unserialize($grid_data->facility_name)[$key]: "Not Applicable"}}</td>
                                    <td class="w-15">{{unserialize($grid_data->IDnumber)[$key] ?  unserialize($grid_data->IDnumber)[$key] : "Not Applicable" }}</td>
                                    <td class="w-15">{{unserialize($grid_data->Remarks)[$key] ?  unserialize($grid_data->Remarks)[$key] : "Not Applicable" }}</td>
                                   
                                </tr>
                                @endforeach
                                @else
                                <tr>
                                    <td>Not Applicable</td>
                                    <td>Not Applicable</td>
                                    <td>Not Applicable</td>
                                    <td>Not Applicable</td>
                                   
                                </tr>
                                @endif
                            </table>
                        </div>
                    </div>

                    <div class="block">
                        <div class="block-head">
                            Document Details 
                        </div>
                        <div class="border-table">
                            <table>
                                <tr class="table_bg">
                                <th class="w-25">SR no.</th>
                                    <th class="w-25">Number</th>
                                    <th class="w-25">Reference Document Name</th>
                                    <th class="w-25">Remarks</th>
                                
                                </tr>
                                @if(!empty($grid_data1->Number))
                                @foreach (unserialize($grid_data1->Number) as $key => $dataDemo)
                                <tr>
                                    <td class="w-15">{{ $dataDemo ? $key + 1  : "Not Applicable" }}</td>
                                    <td class="w-15">{{ unserialize($grid_data1->Number)[$key] ?  unserialize($grid_data1->Number)[$key]: "Not Applicable"}}</td>
                                    <td class="w-15">{{unserialize($grid_data1->ReferenceDocumentName)[$key] ?  unserialize($grid_data1->ReferenceDocumentName)[$key] : "Not Applicable" }}</td>
                                    <td class="w-15">{{unserialize($grid_data1->Document_Remarks)[$key] ?  unserialize($grid_data1->Document_Remarks)[$key] : "Not Applicable" }}</td>
                                   
                                </tr>
                                @endforeach
                                @else
                                <tr>
                                    <td>Not Applicable</td>
                                    <td>Not Applicable</td>
                                    <td>Not Applicable</td>
                                    <td>Not Applicable</td>
                                   
                                </tr>
                                @endif
                            </table>
                        </div>
                    </div>
        

                       
         
            <div class="block">
                    <div class="block-head">
                        HOD Review
                    </div>
                    <table>
                        <tr>
                            <th class="w-30">HOD Remarks</th>
                            <td class="w-20">@if($data->HOD_Remarks){{ $data->HOD_Remarks }}@else Not Applicable @endif</td>
                        </tr>
                    </table>
                        <div class="border-table">
                            <div class="block-head">
                                HOD Attachments
                            </div>
                            <table>
            
                                <tr class="table_bg">
                                    <th class="w-20">S.N.</th>
                                    <th class="w-60">Attachment</th>
                                </tr>
                                    @if($data->Audit_file)
                                    @foreach(json_decode($data->Audit_file) as $key => $file)
                                        <tr>
                                            <td class="w-20">{{ $key + 1 }}</td>
                                            <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                        </tr>
                                    @endforeach
                                    @else
                                <tr>
                                    <td class="w-20">1</td>
                                    <td class="w-20">Not Applicable</td>
                                </tr>
                                @endif
            
                            </table>
                        </div>
                       
                       
                             
                </div>
            </div>
 
            <div class="block">
                <div class="block-head">
                    QA Initial Review
                </div>
                <table>
                   
                    <tr>
                        <th class="w-20">Initial Deviation category</th>
                        <td class="w-30">@if($data->Deviation_category){{ ($data->Deviation_category) }}@else Not Applicable @endif</td>
                        <th class="w-20">Justification for categorization</th>
                        <td class="w-30">@if($data->Justification_for_categorization){{ $data->Justification_for_categorization }}@else Not Applicable @endif</td>
                    </tr>
                    <tr>
                        <th class="w-20">Investigation Required?</th>
                        <td class="w-30">@if($data->Investigation_required){{ $data->Investigation_required }}@else Not Applicable @endif</td>
                        <th class="w-20">Investigation Details</th>
                        <td class="w-30">@if($data->Investigation_Details){{ $data->Investigation_Details }}@else Not Applicable @endif</td>
                    </tr>
                    <tr>
                        <th class="w-20">Customer Notification Required ?</th>
                        <td class="w-30">@if($data->Customer_notification){{$data->Customer_notification}}@else Not Applicable @endif</td>
                        <th class="w-20">Customers</th>
                        {{-- <td class="w-30">@if($data->customers){{ $data->customers }}@else Not Applicable @endif</td> --}}
                        @php
                        $customer = DB::table('customer-details')->where('id', $data->customers)->first();
                        $customer_name = $customer ? $customer->customer_name : 'Not Applicable';
                    @endphp
                    
                    <td>
                        @if($data->customers)
                            {{ $customer_name }}
                        @else
                            Not Applicable
                        @endif
                    </td>
                    </tr>

                    <tr>
                        <th class="w-20">Related Records</th>
                        <td class="w-30">@if($data->related_records){{$data->related_records }}@else Not Applicable @endif</td>
                        <th class="w-20">QA Initial Remarks</th>
                        <td class="w-30">@if($data->QAInitialRemark){{$data->QAInitialRemark }}@else Not Applicable @endif</td>
                        
                    </tr>

                </table>
            </div>    
            
            <div class="border-table">
                <div class="block-head">
                    QA Initial Attachments
                </div>
                <table>

                    <tr class="table_bg">
                        <th class="w-20">S.N.</th>
                        <th class="w-60">Attachment</th>
                    </tr>
                        @if($data->Initial_attachment)
                        @foreach(json_decode($data->Initial_attachment) as $key => $file)
                            <tr>
                                <td class="w-20">{{ $key + 1 }}</td>
                                <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                            </tr>
                        @endforeach
                        @else
                    <tr>
                        <td class="w-20">1</td>
                        <td class="w-20">Not Applicable</td>
                    </tr>
                    @endif

                </table>
            </div>
            <div class="block">
                <div class="head">
                    <div class="block-head">
                      CFT
                    </div>
                    <div class="head">
                        <div class="block-head">
                            Production
                        </div>
                     <table>

                                <tr>
                            
                                    <th class="w-20">Production Review Required ?
                                    </th>
                                    <td class="w-30">
                                        <div>
                                            @if($data7->Production_Review){{ $data7->Production_Review }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                    <th class="w-20">Production Person</th>
                                    <td class="w-30">
                                        <div>
                                            @if($data7->Production_person){{ $data7->Production_person }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                </tr>
                                
                                
                                <tr>
                            
                                    <th class="w-20">Impact Assessment (By Production)</</th>
                                    <td class="w-30">
                                        <div>
                                            @if($data7->Production_assessment){{ $data7->Production_assessment }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                    <th class="w-20">Production Feedback</th>
                                    <td class="w-30">
                                        <div>
                                            @if($data7->Production_feedback){{ $data7->Production_feedback }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                            
                                    <th class="w-20">Production Review Completed By</th>
                                    <td class="w-30">
                                        <div>
                                            @if($data7->Production_Review_Completed_By){{ $data7->production_by }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                    <th class="w-20">Production Review Completed On</th>
                                    <td class="w-30">
                                        <div>
                                            @if($data7->production_on){{ $data7->production_on }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                </tr>
                               
                    </table>
                 </div>  
            <div class="border-table">
                <div class="block-">
                    Production Attachments 
                </div>                                     
                <table>

                    <tr class="table_bg">
                        <th class="w-20">S.N.</th>
                        <th class="w-60">Attachment</th>
                    </tr>
                        @if($data7->production_attachment)
                        @foreach(json_decode($data7->production_attachment) as $key => $file)
                            <tr>
                                <td class="w-20">{{ $key + 1 }}</td>
                                <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                            </tr>
                        @endforeach
                        @else
                    <tr>
                        <td class="w-20">1</td>
                        <td class="w-20">Not Applicable</td>
                    </tr>
                    @endif

                </table>
            </div>
            
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Warehouse
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Warehouse Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Warehouse_review){{ $data7->Warehouse_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Warehouse Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Warehouse_notification){{ $data7->Warehouse_notification }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Warehouse)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Warehouse_assessment){{ $data7->Warehouse_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Warehouse Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Warehouse_feedback){{ $data7->Warehouse_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Warehouse Review Completed By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Warehouse_by){{ $data7->Warehouse_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Warehouse Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Warehouse_Review_Completed_On){{ $data7->Warehouse_Review_Completed_On }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Production Attachments 2
                    </div>                                    
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Warehouse_attachment)
                            @foreach(json_decode($data7->Warehouse_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div>    
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Quality Control
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Quality Control Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Quality_review){{ $data7->Quality_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Quality Control Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Quality_Control_Person){{ $data7->Quality_Control_Person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Quality Control)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Quality_Control_assessment){{ $data7->Quality_Control_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Quality Control Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Quality_Control_feedback){{ $data7->Quality_Control_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Quality Review Completed By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->QualityAssurance__by){{ $data7->QualityAssurance__by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Quality Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Quality_Control_on){{ $data7->Quality_Control_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Quality Control Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Quality_Control_attachment)
                            @foreach(json_decode($data7->Quality_Control_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div>  
           
            
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Quality Assurance
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Quality Assurance Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Quality_Assurance){{ $data7->Quality_Assurance }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Quality Assurance Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->QualityAssurance_person){{ $data7->QualityAssurance_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Quality Assurance)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->QualityAssurance_assessment){{ $data7->QualityAssurance_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Quality Assurance feedback Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Quality_Assurance_feedback){{ $data7->Quality_Assurance_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Quality Assurance Review Completed By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->QualityAssurance_by){{ $data7->QualityAssurance_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Quality Assurance Review Completed  On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->QualityAssurance_on){{ $data7->QualityAssurance_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Quality Assurance Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Quality_Assurance_attachment)
                            @foreach(json_decode($data7->Quality_Assurance_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div>   
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Engineering 
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Engineering Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Engineering_review){{ $data7->Engineering_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Engineering Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Engineering_person){{ $data7->Engineering_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Engineering)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Engineering_assessment){{ $data7->Engineering_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Engineering Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Engineering_feedback){{ $data7->Engineering_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Engineering Review Completed  By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Engineering_by){{ $data7->Engineering_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20"> Engineering Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Engineering_on){{ $data7->Engineering_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Engineering Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Engineering_attachment)
                            @foreach(json_decode($data7->Engineering_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div> 
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Analytical Development Laboratory
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Analytical Development Laboratory Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Analytical_Development_review){{ $data7->Analytical_Development_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Analytical Development Laboratory Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Analytical_Development_person){{ $data7->Analytical_Development_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Analytical Development Laboratory)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Analytical_Development_assessment){{ $data7->Analytical_Development_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Analytical Development Laboratory  Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Analytical_Development_feedback){{ $data7->Analytical_Development_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Analytical Development Laboratory Review Completed By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Analytical_Development_by){{ $data7->Analytical_Development_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Analytical Development Laboratory Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Analytical_Development_on){{ $data7->Analytical_Development_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Analytical Development Laboratory Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Analytical_Development_attachment)
                            @foreach(json_decode($data7->Analytical_Development_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div>
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Process Development Laboratory / Kilo Lab
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Process Development Laboratory / Kilo Lab Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Kilo_Lab_review){{ $data7->Kilo_Lab_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Process Development Laboratory / Kilo Lab Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Kilo_Lab_person){{ $data7->Kilo_Lab_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Process Development Laboratory / Kilo Lab)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Kilo_Lab_assessment){{ $data7->Kilo_Lab_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Process Development Laboratory / Kilo Lab  Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Kilo_Lab_feedback){{ $data7->Kilo_Lab_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Process Development Laboratory / Kilo Lab Review Completed By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Kilo_Lab_attachment_by){{ $data7->Kilo_Lab_attachment_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Process Development Laboratory / Kilo Lab Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Kilo_Lab_attachment_on){{ $data7->Kilo_Lab_attachment_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Process Development
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Kilo_Lab_attachment)
                            @foreach(json_decode($data7->Kilo_Lab_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div>
            
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Technology Transfer / Design 
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Technology Transfer / Design Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Technology_transfer_review){{ $data7->Technology_transfer_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Technology Transfer / Design Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Technology_transfer_person){{ $data7->Technology_transfer_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Technology Transfer / Design)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Technology_transfer_assessment){{ $data7->Technology_transfer_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Technology Transfer / Design Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Technology_transfer_feedback){{ $data7->Technology_transfer_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Technology Transfer / Design Review Completed  By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Technology_transfer_by){{ $data7->Technology_transfer_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20"> Technology Transfer / Design Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Technology_transfer_on){{ $data7->Technology_transfer_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Technology Transfer / Design Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Technology_transfer_attachment)
                            @foreach(json_decode($data7->Technology_transfer_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div> 
        
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Environment, Health & Safety 
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Environment, Health & Safety Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Environment_Health_review){{ $data7->Environment_Health_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Environment, Health & Safety Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Environment_Health_Safety_person){{ $data7->Environment_Health_Safety_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By  Environment, Health & Safety)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Health_Safety_assessment){{ $data7->Health_Safety_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Environment, Health & Safety Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Health_Safety_feedback){{ $data7->Health_Safety_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Environment, Health & Safety Review Completed  By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->production_by){{ $data7->Human_Resource_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20"> Environment, Health & Safety Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Human_Resource_on){{ $data7->Human_Resource_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Environment, Health & Safety Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Human_Resource_attachment)
                            @foreach(json_decode($data7->Human_Resource_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div> 
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Human Resource & Administration 
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Human Resource & Administration Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Human_Resource_review){{ $data7->Human_Resource_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Human Resource & Administration Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Human_Resource_person){{ $data7->Human_Resource_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Human Resource & Administration)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Human_Resource_assessment){{ $data7->Human_Resource_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Human Resource & Administration Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Human_Resource_feedback){{ $data7->Human_Resource_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Human Resource & Administration Review Completed  By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Human_Resource_by){{ $data7->production_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20"> Human Resource & Administration Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->production_on){{ $data7->production_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Human Resource & Administration Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Initial_attachment)
                            @foreach(json_decode($data7->Initial_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div> 
            ---
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Information Technology
 
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Information Technology Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Information_Technology_review){{ $data7->Information_Technology_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Information Technology Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Information_Technology_person){{ $data7->Information_Technology_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Information Technology)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Information_Technology_assessment){{ $data7->Information_Technology_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Information Technology Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Information_Technology_feedback){{ $data7->Information_Technology_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Information Technology Review Completed  By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Information_Technology_by){{ $data7->Information_Technology_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20"> Information Technology Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Information_Technology_on){{ $data7->Information_Technology_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Information Technology Attachments 
                     </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Information_Technology_attachment)
                            @foreach(json_decode($data7->Information_Technology_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div> 
            
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Project Management
 
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Project Management Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Project_management_review){{ $data7->Project_management_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Project Management Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Project_management_person){{ $data7->Project_management_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Project Management)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Project_management_assessment){{ $data7->Project_management_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Project Management Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Project_management_feedback){{ $data7->Project_management_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Project Management Review Completed  By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Project_management_by){{ $data7->Project_management_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20"> Project Management Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Project_management_on){{ $data7->Project_management_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Project Management Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Project_management_attachment)
                            @foreach(json_decode($data7->Project_management_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div>
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Other's 1 ( Additional Person Review From Departments If Required)
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Other's 1 Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other1_review){{ $data7->Other1_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 1 Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other1_person){{ $data7->Other1_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 1 Department</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other1_Department_person){{ $data7->Other1_Department_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Other's 1)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other1_assessment){{ $data7->Other1_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 1 Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other1_feedback){{ $data7->Other1_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Other's 1 Review Completed  By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other1_by){{ $data7->Other1_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20"> Other's 1 Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other1_on){{ $data7->Other1_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Other's 1 Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Other1_attachment)
                            @foreach(json_decode($data7->Other1_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div> 
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Other's 2 ( Additional Person Review From Departments If Required)
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Other's 2 Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other2_review){{ $data7->Other2_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 2 Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other2_person){{ $data7->Other2_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 2 Department</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other2_Department_person){{ $data7->Other2_Department_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Other's 2)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other2_assessment){{ $data7->Other2_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 2 Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other2_feedback){{ $data7->Other2_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Other's 2 Review Completed  By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other2_by){{ $data7->Other2_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20"> Other's 2 Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other2_on){{ $data7->Other2_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Other's 2 Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Other2_attachment)
                            @foreach(json_decode($data7->Other2_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div> 
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Other's 3 ( Additional Person Review From Departments If Required)
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Other's 3 Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other3_review){{ $data7->Other3_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 3 Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other3_person){{ $data7->Other3_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 3 Department</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other3_Department_person){{ $data7->Other3_Department_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Other's 3)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other3_assessment){{ $data7->Other3_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 3 Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other3_feedback){{ $data7->Other3_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Other's 3 Review Completed  By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other3_by){{ $data7->Other3_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20"> Other's 3 Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other3_on){{ $data7->Other3_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Other's 3 Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Other3_attachment)
                            @foreach(json_decode($data7->Other3_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">4</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div> 
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Other's 4 ( Additional Person Review From Departments If Required)
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Other's 4 Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other4_review){{ $data7->Other4_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 4 Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other4_person){{ $data7->Other4_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 4 Department</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other4_Department_person){{ $data7->Other4_Department_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Other's 4)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other4_assessment){{ $data7->Other4_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 4 Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other4_feedback){{ $data7->Other4_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Other's 4 Review Completed  By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other4_by){{ $data7->Other4_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20"> Other's 4 Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other4_on){{ $data7->Other4_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Other's 4 Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Other4_attachment)
                            @foreach(json_decode($data7->Other4_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div> 
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Other's 5 ( Additional Person Review From Departments If Required)
                    </div>
                    <table>

                            <tr>
                        
                                <th class="w-20">Other's 5 Review Required ?
                                </th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other5_review){{ $data7->Other5_review }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 5 Person</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other5_person){{ $data7->Other5_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 5 Department</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other5_Department_person){{ $data7->Other5_Department_person }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            
                            <tr>
                        
                                <th class="w-20">Impact Assessment (By Other's 5)</</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other5_assessment){{ $data7->Other5_assessment }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20">Other's 5 Feedback</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other5_feedback){{ $data7->Other5_feedback }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                            <tr>
                        
                                <th class="w-20">Other's 5 Review Completed  By</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other5_by){{ $data7->Other5_by }}@else Not Applicable @endif
                                    </div>
                                </td>
                                <th class="w-20"> Other's 5 Review Completed On</th>
                                <td class="w-30">
                                    <div>
                                        @if($data7->Other5_on){{ $data7->Other5_on }}@else Not Applicable @endif
                                    </div>
                                </td>
                            </tr>
                    </table>
                    </div>  
                  <div class="border-table">
                    <div class="block-">
                        Other's 5 Attachments 
                    </div>                                   
                    <table>
    
                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data7->Other5_attachment)
                            @foreach(json_decode($data7->Other5_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif
    
                    </table>
                </div>
            </div> 
    
   
            <div class="block">
                <div class="head">
                    <div class="block-head">
                        Investigation & CAPA
                    </div>
                    <table>

                                <tr>
                            
                                    <th class="w-20">Investigation Summary
                                    </th>
                                    <td class="w-30">
                                        <div>
                                            @if($data->Investigation_Summary){{ $data->Investigation_Summary }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                    <th class="w-20">Impact Assessment</th>
                                    <td class="w-30">
                                        <div>
                                            @if($data->Impact_assessment){{ $data->Impact_assessment }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <th class="w-20">Root cause</th>
                                    <td class="w-80">
                                        <div>
                                            @if($data->Root_cause){{ $data->Root_cause }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                </tr>
                                
                                <tr>
                            
                                    <th class="w-20">CAPA Required ?</th>
                                    <td class="w-30">
                                        <div>
                                            @if($data->CAPA_Rquired){{ $data->CAPA_Rquired }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                    <th class="w-20">CAPA Type?</th>
                                    <td class="w-30">
                                        <div>
                                            @if($data->capa_type){{ $data->capa_type }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                            
                                    <th class="w-20">CAPA Description</th>
                                    <td class="w-30">
                                        <div>
                                            @if($data->CAPA_Description){{ $data->CAPA_Description }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                    <th class="w-20">Post Categorization Of Deviationt</th>
                                    <td class="w-30">
                                        <div>
                                            @if($data->Post_Categorization){{ $data->Post_Categorization }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                            
                                    <th class="w-20">Revised Categorization Justification
                                    </th>
                                    <td class="w-30">
                                        <div>
                                            @if($data->Investigation_Of_Review){{ $data->Investigation_Of_Review }}@else Not Applicable @endif
                                        </div>
                                    </td>
                                    
                                </tr>
                 </table>
            </div>  
            <div class="border-table">
                <div class="block-head">
                    Investigation Attachment
                </div>
                <table>

                    <tr class="table_bg">
                        <th class="w-20">S.N.</th>
                        <th class="w-60">Attachment</th>
                    </tr>
                        @if($data->Investigation_attachment)
                        @foreach(json_decode($data->Investigation_attachment) as $key => $file)
                            <tr>
                                <td class="w-20">{{ $key + 1 }}</td>
                                <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                            </tr>
                        @endforeach
                        @else
                    <tr>
                        <td class="w-20">1</td>
                        <td class="w-20">Not Applicable</td>
                    </tr>
                    @endif

                </table>
            </div>
            <div class="border-table">
                <div class="block-head">
                    CAPA Attachment
                </div>
                <table>

                    <tr class="table_bg">
                        <th class="w-20">S.N.</th>
                        <th class="w-60">Attachment</th>
                    </tr>
                        @if($data->Capa_attachment)
                        @foreach(json_decode($data->Capa_attachment) as $key => $file)
                            <tr>
                                <td class="w-20">{{ $key + 1 }}</td>
                                <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                            </tr>
                        @endforeach
                        @else
                    <tr>
                        <td class="w-20">1</td>
                        <td class="w-20">Not Applicable</td>
                    </tr>
                    @endif

                </table>
            </div>
                
            <div class="block">
                <div class="block-head">
                    QA Final Review
                </div>
                <table>

                        <tr>
                        <th class="w-20">QA Feedbacks</th>
                        <td class="w-30">@if($data->QA_Feedbacks){{ $data->QA_Feedbacks }}@else Not Applicable @endif</td>
                        
                    </table>
                </div>
                <div class="border-table">
                    <div class="block-head">
                        QA Attachments
                    </div>
                    <table>

                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data->QA_attachments)
                            @foreach(json_decode($data->QA_attachments) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif

                    </table>
                </div>
            </div>
            <div class="block">
                <div class="block-head">
                    QAH/Designee Approval
                </div>
                <table>

                        <tr>
                        <th class="w-20">Closure Comments</th>
                        <td class="w-30">@if($data->Closure_Comments){{ $data->Closure_Comments }}@else Not Applicable @endif</td>
                        <th class="w-20">Disposition of Batch</th>
                        <td class="w-30">@if($data->Disposition_Batch){{ $data->Disposition_Batch }}@else Not Applicable @endif</td>
                        
                    </table>
                </div>
                <div class="border-table">
                    <div class="block-head">
                        Closure Attachments
                    </div>
                    <table>

                        <tr class="table_bg">
                            <th class="w-20">S.N.</th>
                            <th class="w-60">Attachment</th>
                        </tr>
                            @if($data->closure_attachment)
                            @foreach(json_decode($data->closure_attachment) as $key => $file)
                                <tr>
                                    <td class="w-20">{{ $key + 1 }}</td>
                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                </tr>
                            @endforeach
                            @else
                        <tr>
                            <td class="w-20">1</td>
                            <td class="w-20">Not Applicable</td>
                        </tr>
                        @endif

                    </table>
                </div>
            </div>  
        </div>          
                

            <div class="block">
                <div class="block-head">
                    Activity Log
                </div>
                <table>
                    <tr>
                        <th class="w-20">Submit By</th>
                        <td class="w-30">{{ $data->submit_by }}</td>
                        <th class="w-20">Submit On</th>
                        <td class="w-30">{{ $data->submit_on }}</td>
                        <th class="w-20">Submit Comments</th>
                        <td class="w-30">{{ $data->submit_comment }}</td>
                    </tr>
                    <tr>
                        <th class="w-20">HOD Review Complete By</th>
                        <td class="w-30">{{ $data->HOD_Review_Complete_By}}</td>
                        <th class="w-20">HOD Review Complete On</th>
                        <td class="w-30">{{ $data->HOD_Review_Complete_On }}</td>
                        <th class="w-20">HOD Review Comments</th>
                        <td class="w-30">{{ $data->HOD_Review_Comments }}</td> 
                    </tr>
                    <tr>
                        <th class="w-20">QA Initial Review Complete by</th>
                        <td class="w-30">{{ $data->QA_Initial_Review_Complete_By }}</td>
                        <th class="w-20">QA Initial Review Complete On</th>
                        <td class="w-30">{{ Helpers::getdateFormat($data->QA_Initial_Review_Complete_On) }}</td>
                        <th class="w-20">QA Initial Review Comments</th>
                        <td class="w-30">{{ $data->QA_Initial_Review_Comments }}</td> 
                    </tr>
                    <tr>
                        <th class="w-20">CFT Review Complete By</th>
                        <td class="w-30">{{ $data->CFT_Review_Complete_By }}</td>
                        <th class="w-20">CFT Review Complete On</th>
                        <td class="w-30">{{ $data->CFT_Review_Complete_On }}</td>
                        <th class="w-20">CFT Review Comments</th>
                        <td class="w-30">{{ $data->CFT_Review_Comments }}</td>
                    </tr>
                    <tr>
                        <th class="w-20">QA Final Review Complete By</th>
                        <td class="w-30">{{ $data->QA_Final_Review_Complete_By }}</td>
                        <th class="w-20">QA Final Review Complete On</th>
                        <td class="w-30">{{ $data->QA_Final_Review_Complete_On }}</td>
                        <th class="w-20">QA Final Review Comments</th>
                        <td class="w-30">{{ $data->QA_Final_Review_Comments }}</td>
                    </tr>
                    <tr>
                        <th class="w-20">Approved By</th>
                        <td class="w-30">{{ $data->Approved_By }}</td>
                        <th class="w-20">Approved ON</th>
                        <td class="w-30">{{ $data->Approved_On }}</td>
                        <th class="w-20">Approved Comments</th>
                        <td class="w-30">{{ $data->Approved_Comments }}</td>
                   


                </table>
            </div>
        </div>
    
    </div>

    
     {{-- <div class="block-child">
        Immediate Child - CAPA
    </div> --}}
<div class="sub-child">
    <table style="border-collapse: collapse;">
        <tr>
            <td style="width: 40%; border: 1.5px solid #150707; padding: -5px;">
                <h4> Immediate Child -<span style="color: black; font-weight: normal;"> CAPA</span></h4>
            </td>
            <td style="width: 30%; border: 1.5px solid #150707; padding: -5px;">
                <h4>ID-<span style="color: black; font-weight: normal;">{{ isset($data1->record) ? str_pad($data1->record, 4, '0', STR_PAD_LEFT) : 'Yet Not Created ' }}</span></h4>

            </td>
            <td style="width: 30%; border: 1.5px solid #150707; padding: -5px;">
                <h4>Status-<span style="color: black; font-weight: normal;">{{ $data1->status ?? 'Yet Not Created' }}</span></h4>
            </td>
        </tr>
    </table>
    
</div> 
    @if(!empty($data1))
<div class="block">
    <div class="block-head">
        General Information
    </div>
    <table>

        <tr>  {{ $data1->created_at }} added by {{ $data1->originator }}
            <th class="w-20">Initiator</th>
            <td class="w-30">{{ $data1->originator }}</td>
            <th class="w-20">Date of Initiation</th>
            <td class="w-30">{{ Helpers::getdateFormat($data1->created_at) }}</td>
        </tr>
        <tr>
            <th class="w-20">Record Number</th>
            <td class="w-30">@if($data1->record){{  str_pad($data1->record, 4, '0', STR_PAD_LEFT) }} @else Not Applicable @endif</td>
            <th class="w-20">Site/Location Code</th>
            <td class="w-30"> {{ Helpers::getDivisionName(session()->get('division')) }}</td>
        </tr>
        <tr>
            <th class="w-20">Initiator Group</th>
            <td class="w-30">@if($data1->initiator_Group){{ $data1->initiator_Group }} @else Not Applicable @endif</td>
            <th class="w-20">Initiator Group Code</th>
            <td class="w-80">{{ $data1->initiator_group_code }}</td>

         </tr>
         <tr>
            <th class="w-20">Short Description</th>
            <td class="w-80">@if($data1->short_description){{ $data1->short_description }}@else Not Applicable @endif</td>
            <th class="w-20">Severity Level</th>
            <td class="w-80">{{ $data1->severity_level_form }}</td>

           
        </tr>
        <tr>
        <th class="w-20">Assigned To</th>
            <td class="w-30">@if($data1->assign_to){{ Helpers::getInitiatorName($data1->assign_to) }} @else Not Applicable @endif</td>
            <th class="w-20">Due Date</th>
            <td class="w-80"> @if($data1->due_date){{ $data1->due_date }} @else Not Applicable @endif</td>
           
        </tr>

       
        <tr>
            <th class="w-20">Initiated Through</th>
            <td class="w-80">@if($data1->initiated_through){{ $data1->initiated_through }}@else Not Applicable @endif</td>

            <th class="w-20">Others</th>
            <td class="w-80">@if($data1->initiated_through_req){{ $data1->initiated_through_req }}@else Not Applicable @endif</td>
        </tr>
        <tr>
            <th class="w-20">Repeat</th>
            <td class="w-80">@if($data1->repeat){{ $data1->repeat }}@else Not Applicable @endif</td>
            <th class="w-20">Repeat Nature</th>
            <td class="w-80">@if($data1->repeat_nature){{ $data1->repeat_nature }}@else Not Applicable @endif</td>
        </tr>
        <tr>
            <th class="w-20">Problem Description</th>
            <td class="w-80">@if($data1->problem_description){{ $data1->problem_description }}@else Not Applicable @endif</td>

        </tr>
         <tr>
            <th class="w-20">CAPA Team</th>
            <td class="w-80">@if($data1->capa_team){{  Helpers::getInitiatorName($data1->capa_team) }}@else Not Applicable @endif</td>
        </tr>
        <tr>
                <th class="w-20">Reference Records</th>
                <td class="w-80">@if($data1->capa_related_record){{ Helpers::getDivisionName($data1->division_id) }}/CAPA/{{ date('Y') }}/{{ Helpers::recordFormat($data1->record) }}@else Not Applicable @endif</td>
              
            </tr>
        <tr>
            <th class="w-20">Initial Observation</th>
            <td class="w-80">@if($data1->initial_observation){{ $data1->initial_observation}}@else Not Applicable @endif</td>
            <th class="w-20">Interim Containnment</th>
            <td class="w-80">@if($data1->interim_containnment){{ $data1->interim_containnment }}@else Not Applicable @endif</td>
        </tr>
        <tr>
            <th class="w-20">Containment Comments</th>
            <td class="w-80">@if($data1->containment_comments){{ $data1->containment_comments }}@else Not Applicable @endif</td>

        </tr>
        <tr>
            <th class="w-20">CAPA QA Comments</th>
            <td class="w-80">@if($data1->capa_qa_comments){{ $data1->capa_qa_comments }}@else Not Applicable @endif</td>
        </tr>
    <div class="block-head">
           Capa Attachement
        </div>
          <div class="border-table">
            <table>
                <tr class="table_bg">
                    <th class="w-20">S.N.</th>
                    <th class="w-60">Attachment</th>
                </tr>
                    @if($data1->capa_attachment)
                    @foreach(json_decode($data1->capa_attachment) as $key => $file)
                        <tr>
                            <td class="w-20">{{ $key + 1 }}</td>
                            <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                        </tr>
                    @endforeach
                    @else
                    <tr>
                        <td class="w-20">1</td>
                        <td class="w-20">Not Applicable</td>
                    </tr>
                @endif

            </table>
          </div>
    </table>
</div>
<div class="block">
    <div class="block-head">
        Activity Log
    </div>
    <table>
        <tr>
            <th class="w-20">Plan Proposed By
            </th>
            <td class="w-30">{{ $data1->plan_proposed_by }}</td>
            <th class="w-20">
                Plan Proposed On</th>
            <td class="w-30">{{ $data1->plan_proposed_on }}</td>
        </tr>
        <tr>
            <th class="w-20">Plan Approved By
            </th>
            <td class="w-30">{{ $data1->plan_approved_by }}</td>
            <th class="w-20">
                Plan Approved On</th>
            <td class="w-30">{{ $data1->Plan_approved_on }}</td>
        </tr>
        <tr>
            <th class="w-20">QA More Info Required By
            </th>
            <td class="w-30">{{ $data1->qa_more_info_required_by }}</td>
            <th class="w-20">
                QA More Info Required On</th>
            <td class="w-30">{{ $data1->qa_more_info_required_on }}</td>
        </tr>
        <tr>
            <th class="w-20">Cancelled By
            </th>
            <td class="w-30">{{ $data1->cancelled_by }}</td>
            <th class="w-20">
                Cancelled On</th>
            <td class="w-30">{{ $data1->cancelled_on }}</td>
        </tr>
        <tr>
            <th class="w-20">Completed By
            </th>
            <td class="w-30">{{ $data1->completed_by }}</td>
            <th class="w-20">
                Completed On</th>
            <td class="w-30">{{ $data1->completed_on }}</td>
        </tr>
        <tr>
            <th class="w-20">Approved By</th>
            <td class="w-30">{{ $data1->approved_by }}</td>
            <th class="w-20">Approved On</th>
            <td class="w-30">{{ $data1->approved_on }}</td>
        </tr>

        <tr>
            <th class="w-20">Rejected By</th>
            <td class="w-30">{{ $data1->rejected_by }}</td>
            <th class="w-20">Rejected On</th>
            <td class="w-30">{{ $data1->rejected_on }}</td>
        </tr>

    </table>
</div>
@else
<div>
    <h4>There is no CAPA Child</h4>
   
</div>
     @endif

     <div class="sub-child">
        <table style="border-collapse: collapse;">
            <tr>
                <td style="width: 40%; border: 1.5px solid #150707; padding: -5px;">
                    <h4> Immediate Childc-<span style="color: black; font-weight: normal;"> Extension</span></h4>
                </td>
                <td style="width: 30%; border: 1.5px solid #150707; padding: -5px;">
                    <h4>ID- <span style="color: black; font-weight: normal;">{{ isset($data3->record) ? str_pad($data3->record, 4, '0', STR_PAD_LEFT) : 'Yet Not Created' }}</span></h4>
    
                </td>
                <td style="width: 30%; border: 1.5px solid #150707; padding: -5px;">
                    <h4>Status-<span style="color: black; font-weight: normal;">{{ $data3->status ?? 'Yet Not Created' }}</span></h4>
                </td>
            </tr>
        </table>
        
    </div> 
                    @if(!empty($data3))
                    <div class="inner-block">
                        <div class="content-table">
                            <div class="block">
                                <div class="block-head">
                                      Extension Details
                                </div>
                                <table>
                                    <tr>
                                        <th class="w-20">Record Number</th>
                                        <td class="w-30">@if($data3->record){{  str_pad($data3->record, 4, '0', STR_PAD_LEFT) }} @else Not Applicable @endif</td>
                                        <th class="w-20">Division Code</th>
                                        <td class="w-30">@if($data3->division_id){{   Helpers::getDivisionName($data3->division_id) }} @else Not Applicable @endif</td>
                                    </tr>
                
                                    <tr>  {{ $data3->created_at }} added by {{ $data3->originator }}
                                        <th class="w-20">Initiator</th>
                                        <td class="w-30">{{ Helpers::getInitiatorName($data3->initiator_id) }}</td>
                                        <th class="w-20">Date of Initiation</th>
                                        <td class="w-30">{{ Helpers::getdateFormat($data3->created_at) }}</td>
                                    </tr>
                                    
                                    <tr>
                                       <th class="w-20">Current Parent DueDate</th>
                                        <td class="w-30">@if($data3->due_date){{ Helpers::getdateFormat($data3->due_date) }} @else Not Applicable @endif</td>
                                        <th class="w-20">Revised Due Date</th>
                                        <td class="w-80"> @if($data3->revised_date){{ Helpers::getdateFormat($data3->revised_date) }} @else Not Applicable @endif</td>
                                       
                                    </tr>
                                     <tr>
                                        <th class="w-20">Short Description</th>
                                        <td class="w-80">@if($data3->short_description){{ $data3->short_description }}@else Not Applicable @endif</td>
                                    </tr>
                                    <tr>
                                        <th class="w-20">Justification of Extention</th>
                                        <td class="w-80">@if($data3->justification){{ $data3->justification }}@else Not Applicable @endif</td>
                                        <th class="w-20">Initiated Through</th>
                                        <td class="w-80">@if($data3->initiated_through){{ $data3->initiated_through }}@else Not Applicable @endif</td>
                                    </tr>
                                    <tr>                    
                                        <th class="w-20">Reference Record</th>
                                        <td class="w-80"> @if($data3->initiated_if_other){{ $data3->initiated_if_other }} @else Not Applicable @endif</td>    
                                        <th class="w-20">Approver</th>
                                        <td class="w-30">@if($data3->approver1){{ Helpers::getInitiatorName($data3->approver1) }} @else Not Applicable @endif</td>                  
                                    </tr>
                                    <div class="block-head">
                                        Extention Attachments
                                    </div>
                                      <div class="border-table">
                                        <table>
                                            <tr class="table_bg">
                                                <th class="w-20">S.N.</th>
                                                <th class="w-60">File </th>
                                            </tr>
                                                @if($data3->extention_attachment)
                                                @foreach(json_decode($data3->extention_attachment) as $key => $file)
                                                    <tr>
                                                        <td class="w-20">{{ $key + 1 }}</td>
                                                        <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                    </tr>
                                                @endforeach
                                                @else
                                                <tr>
                                                    <td class="w-20">1</td>
                                                    <td class="w-20">Not Applicable</td>
                                                </tr>
                                            @endif
                
                                        </table>
                                    </div>
                                </table>
                            </div>
                            <div class="inner-block">
                        <div class="content-table">
                            <div class="block">
                                <div class="block-head">
                                   QA Approver
                                </div>
                                <table>
                                     <tr>
                                        <th class="w-20">Approver Comments</th>
                                        <td class="w-80">@if($data3->approver_comments){{ $data3->approver_comments }}@else Not Applicable @endif</td>
                                     </tr>
                                  </table>
                                
                                    <div class="block-head">
                                    Closure Attachments
                                    </div>
                                      <div class="border-table">
                                        <table>
                                            <tr class="table_bg">
                                                <th class="w-20">S.N.</th>
                                                <th class="w-60">Attachment</th>
                                            </tr>
                                                @if($data3->closure_attachments)
                                                @foreach(json_decode($data3->closure_attachments) as $key => $file)
                                                    <tr>
                                                        <td class="w-20">{{ $key + 1 }}</td>
                                                        <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                    </tr>
                                                @endforeach
                                                @else
                                                <tr>
                                                    <td class="w-20">1</td>
                                                    <td class="w-20">Not Applicable</td>
                                                </tr>
                                            @endif
                
                                        </table>
                                      </div>
                </div>
                <div class="block">
                    <div class="block-head">
                    Activity Log
                    </div>
                    <table>
                        <tr>
                            <th class="w-20">Submitted By
                            </th>
                            <td class="w-30">{{ $data3->submitted_by }}</td>
                            <th class="w-20">
                            Submitted On</th>
                            <td class="w-30">{{ $data3->submitted_on }}</td>
                        </tr>
                        <tr>
                            <th class="w-20">Cancelled By
                            </th>
                            <td class="w-30">{{ $data3->cancelled_by }}</td>
                            <th class="w-20">
                            Cancelled On</th>
                            <td class="w-30">{{ $data3->cancelled_on }}</td>
                        </tr>
                        <tr>
                            <th class="w-20">Ext Approved By
                            </th>
                            <td class="w-30">{{ $data3->ext_approved_by }}</td>
                            <th class="w-20">
                            Ext Approved On</th>
                            <td class="w-30">{{ $data3->ext_approved_on }}</td>
                        </tr>
                        <tr>
                            <th class="w-20">More Information Required By
                            </th>
                            <td class="w-30">{{ $data3->more_information_required_by }}</td>
                            <th class="w-20">
                            More Information Required On</th>
                            <td class="w-30">{{ $data3->more_information_required_on }}</td>
                        </tr>
                        <tr>
                            <th class="w-20">Rejected By</th>
                            <td class="w-30">{{ $data3->rejected_by }}</td>
                            <th class="w-20">Rejected On</th>
                            <td class="w-30">{{ $data3->rejected_on }}</td>
                        </tr>
                       
                    </table>
                </div>
                @else
<div>
    <h4>There is no Extension Child</h4>
  
</div>
     @endif
     <div class="sub-child">
        <table style="border-collapse: collapse;">
            <tr>
                <td style="width: 40%; border: 1.5px solid #150707; padding: -5px;">
                    <h4> Immediate Child - <span style="color: black; font-weight: normal;">RCA</span></h4>
                </td>
                <td style="width: 30%; border: 1.5px solid #150707; padding: -5px;">
                    <h4>ID-<span style="color: black; font-weight: normal;"> {{ isset($data2->record) ? str_pad($data2->record, 4, '0', STR_PAD_LEFT) : 'Yet Not Created' }}</span></h4>
    
                </td>
                <td style="width: 30%; border: 1.5px solid #150707; padding: -5px;">
                    <h4>Status-<span style="color: black; font-weight: normal;">{{ $data2->status ?? 'Yet Not Created' }}</span></h4>
                </td>
            </tr>
        </table>
        
    </div> 
                @if(!empty($data2))
                <div class="inner-block">
                    <div class="content-table">
                        <div class="block">
                            <div class="block-head">
                                Investigation
                            </div>
                            <table>
                                <tr>  {{ $data2->created_at }} added by {{ $data2->originator }}
                                    <th class="w-20">Initiator</th>
                                    <td class="w-30">{{ Helpers::getInitiatorName($data2->initiator_id) }}</td>
                                    <th class="w-20">Date Initiation</th>
                                    <td class="w-30">{{ Helpers::getdateFormat($data2->created_at) }}</td>
                                </tr>
                                <tr>
                                    <th class="w-20">Site/Location Code</th>
                                    <td class="w-30">@if($data2->division_code){{ $data2->division_code }} @else Not Applicable @endif</td>
                                    <th class="w-20">Initiator Group</th>
                                    <td class="w-30">@if($data2->Initiator_Group){{ $data2->Initiator_Group }} @else Not Applicable @endif</td>
                                   
                                </tr>
                                <tr>
                                    <th class="w-20">Record Number</th>
                                    <td class="w-30">@if($data2->record){{ $data2->record }} @else Not Applicable @endif</td>
                                    <th class="w-20">Severity Level</th>
                                    <td class="w-30">@if($data2->severity_level){{ $data2->severity_level }} @else Not Applicable @endif</td>
            
                                </tr>
                                <tr>
                                    <th class="w-20">Short Description</th>
                                    <td class="w-80" colspan="3">
                                        @if($data2->short_description){{ $data2->short_description }}@else Not Applicable @endif
                                    </td>
                                    <th class="w-20">Initiator Group Code</th>
                                    <td class="w-30">@if($data2->initiator_group_code){{ $data2->initiator_group_code }} @else Not Applicable @endif</td>
                                </tr>
                                <tr>
                                    <th class="w-20">Due Date</th>
                                    <td class="w-80" colspan="3"> @if($data2->due_date){{ $data2->due_date }} @else Not Applicable @endif</td>
                                    <th class="w-20">Assigned To</th>
                                    <td class="w-30">@if($data2->assign_to){{ Helpers::getInitiatorName($data2->assign_to) }} @else Not Applicable @endif</td>r>
                                <tr>
                                    <th class="w-20">Others</th>
                                    <td class="w-30">@if($data2->initiated_if_other){{ $data2->initiated_if_other }}@else Not Applicable @endif</td>
                                    <th class="w-20">Priority Level</th>
                                    <td class="w-30">@if($data2->priority_level){{ $data2->priority_level }}@else Not Applicable @endif</td>
                                </tr>
                                <tr>
                                    {{-- <th class="w-20">Additional Investigators</th>
                                    <td class="w-30">@if($data2->investigators){{ $data2->investigators }}@else Not Applicable @endif</td> --}}
                                    <th class="w-20">Department(s)</th>
                                    <td class="w-30">@if($data2->department){{ $data2->department }}@else Not Applicable @endif</td>
                                </tr>
                                <tr>
                                    <th class="w-20">Description</th>
                                    <td class="w-30">@if($data2->description){{ $data2->description }}@else Not Applicable @endif</td>
                                    <th class="w-20">Comments</th>
                                    <td class="w-30">@if($data2->comments){{ $data2->comments }}@else Not Applicable @endif</td>
                                </tr>                       
                                <tr>
                                    <th class="w-20">Initiated Through
                                    </th>
                                    <td class="w-30">@if($data2->initiated_through){{ $data2->initiated_through }}@else Not Applicable @endif</td>
                                    <th class="w-20">Related URL</th>
                                    <td class="w-30">@if($data2->related_url){{ $data2->related_url }}@else Not Applicable @endif</td>
                                </tr>
                                
                            </table>
                            <div class="border-table">
                                <div class="block-head">
                                    File Attachment, if any
                                </div>
                                <table>
            
                                    <tr class="table_bg">
                                        <th class="w-20">S.N.</th>
                                        <th class="w-60">Attachmen</th>
                                    </tr>
                                        @if($data2->root_cause_initial_attachment)
                                        @foreach(json_decode($data2->root_cause_initial_attachment) as $key => $file)
                                            <tr>
                                                <td class="w-20">{{ $key + 1 }}</td>
                                                <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                            </tr>
                                        @endforeach
                                        @else
                                    <tr>
                                        <td class="w-20">1</td>
                                        <td class="w-20">Not Applicable</td>
                                    </tr>
                                    @endif
            
                                </table>
                            </div>
            
                        </div>
                        <div class="block">
                            <div class="block-head">
                                Investigation & Root Cause
                            </div>
                                <table>
                                    <tr>
                                        <th class="w-20">Root Cause Methodology</th>
                                        <td class="w-80">@if($data2->root_cause_methodology){{ $data2->root_cause_methodology }}@else Not Applicable @endif</td>
                                    </tr>
            
                                    <tr>
                                        <th class="w-20">Root Cause Description</th>
                                        <td class="w-80">@if($data2->root_cause_description){{ $data2->root_cause_description }}@else Not Applicable @endif</td>
                                        <th class="w-20">Investigation Summary</th>
                                        <td class="w-80">@if($data2->investigation_summary){{ $data2->investigation_summary }}@else Not Applicable @endif</td>
                                    </tr>
                                    <tr>
                                        <th class="w-20">Attachments</th>
                                        <td class="w-80">@if($data2->attachments)<a href="{{ asset('upload/document/',$data2->attachments) }}">{{ $data2->attachments }}@else Not Applicable @endif</td>
                                    </tr>
                                    <tr>
                                        <th class="w-20">Comments</th>
                                        <td class="w-80">@if($data2->comments){{ $data2->comments }}@else Not Applicable @endif</td>
                                    </tr>
                                 
                                </table>
                                <div class="block-head">
                                    Fishbone or Ishikawa Diagram 
                                </div>
                                <table>
                                - <tr>
                                    <th class="w-20">Measurement</th>
                                    {{-- <td class="w-80">@if($riskgrdfishbone->measurement){{ $riskgrdfishbone->measurement }}@else Not Applicable @endif</td> --}}
                                         <td class="w-80">
                                        @php
                                            $measurement = unserialize($data2->measurement);
                                        @endphp
                                        
                                        @if(is_array($measurement))
                                            @foreach($measurement as $value)
                                                {{ htmlspecialchars($value) }}
                                            @endforeach
                                        @elseif(is_string($measurement))
                                            {{ htmlspecialchars($measurement) }}
                                        @else
                                            Not Applicable
                                        @endif
                                          </td>
                                    <th class="w-20">Materials</th>
                                    {{-- <td class="w-80">@if($data2->materials){{ $data2->materials }}@else Not Applicable @endif</td> --}}
                                         <td class="w-80">
                                        @php
                                            $materials = unserialize($data2->materials);
                                        @endphp
                                        
                                        @if(is_array($materials))
                                            @foreach($materials as $value)
                                                {{ htmlspecialchars($value) }}
                                            @endforeach
                                        @elseif(is_string($materials))
                                            {{ htmlspecialchars($materials) }}
                                        @else
                                            Not Applicable
                                        @endif
                                           </td>
                                    
                                </tr>
                                   <tr>
                                    <th class="w-20">Methods</th>
                                    {{-- <td class="w-80">@if($data2->methods){{ $data2->methods }}@else Not Applicable @endif</td> --}}
                                       <td class="w-80">
                                        @php
                                            $methods = unserialize($data2->methods);
                                        @endphp
                                        
                                        @if(is_array($methods))
                                            @foreach($methods as $value)
                                                {{ htmlspecialchars($value) }}
                                            @endforeach
                                        @elseif(is_string($methods))
                                            {{ htmlspecialchars($methods) }}
                                        @else
                                            Not Applicable
                                        @endif
                                       </td>
                                    <th class="w-20">Environment</th>
                                    {{-- <td class="w-80">@if($data2->environment){{ $data2->environment }}@else Not Applicable @endif</td> --}}
                                        <td class="w-80">
                                        @php
                                            $environment = unserialize($data2->environment);
                                        @endphp
                                        
                                        @if(is_array($environment))
                                            @foreach($environment as $value)
                                                {{ htmlspecialchars($value) }}
                                            @endforeach
                                        @elseif(is_string($environment))
                                            {{ htmlspecialchars($environment) }}
                                        @else
                                            Not Applicable
                                        @endif
                                        </td>
                                </tr>
                                <tr>
                                    <th class="w-20">Manpower</th>
                                    {{-- <td class="w-80">@if($data2->manpower){{ $data2->manpower }}@else Not Applicable @endif</td> --}}
                                        <td class="w-80">
                                        @php
                                            $manpower = unserialize($data2->manpower);
                                        @endphp
                                        
                                        @if(is_array($manpower))
                                            @foreach($manpower as $value)
                                                {{ htmlspecialchars($value) }}
                                            @endforeach
                                        @elseif(is_string($manpower))
                                            {{ htmlspecialchars($manpower) }}
                                        @else
                                            Not Applicable
                                        @endif
                                       </td>
                                    <th class="w-20">Machine</th>
                                    {{-- <td class="w-80">@if($data2->machine){{ $data2->machine }}@else Not Applicable @endif</td> --}}
                                      <td class="w-80">
                                        @php
                                            $machine = unserialize($data2->machine);
                                        @endphp
                                        
                                        @if(is_array($machine))
                                            @foreach($machine as $value)
                                                {{ htmlspecialchars($value) }}
                                            @endforeach
                                        @elseif(is_string($machine))
                                            {{ htmlspecialchars($machine) }}
                                        @else
                                            Not Applicable
                                        @endif
                                      </td>
                                </tr>
                                <tr>
                                    <th class="w-20">Problem Statement1</th>
                                    <td class="w-80">@if($data2->problem_statement){{ $data2->problem_statement }}@else Not Applicable @endif</td>
                                  
                                </tr> 
                         </table>
                                    
                         <div class="block-head">
                            Why-Why Chart 
                        </div>
                        <table>
                        - <tr>
                            <th class="w-20">Problem Statement</th>
                            <td class="w-80">@if($data2->why_problem_statement){{ $data2->why_problem_statement }}@else Not Applicable @endif</td>
                            <th class="w-20">Why 1 </th>
                            {{-- <td class="w-80">@if($data2->why_1){{ $data2->why_1 }}@else Not Applicable @endif</td> --}}
                            <td class="w-80">
                                @php
                                    $why_1 = unserialize($data2->why_1);
                                @endphp
                                
                                @if(is_array($why_1))
                                    @foreach($why_1 as $value)
                                        {{ htmlspecialchars($value) }}
                                    @endforeach
                                @elseif(is_string($why_1))
                                    {{ htmlspecialchars($why_1) }}
                                @else
                                    Not Applicable
                                @endif
                                  </td>
                        </tr>
                           <tr>
                            <th class="w-20">Why 2</th>
                            {{-- <td class="w-80">@if($data2->why_2){{ $data2->why_2 }}@else Not Applicable @endif</td> --}}
                            <td class="w-80">
                                @php
                                    $why_2 = unserialize($data2->why_2);
                                @endphp
                                
                                @if(is_array($why_2))
                                    @foreach($why_2 as $value)
                                        {{ htmlspecialchars($value) }}
                                    @endforeach
                                @elseif(is_string($why_2))
                                    {{ htmlspecialchars($why_2) }}
                                @else
                                    Not Applicable
                                @endif
                                  </td>
                            <th class="w-20">Why 3</th>
                            {{-- <td class="w-80">@if($data2->why_3){{ $data2->why_3 }}@else Not Applicable @endif</td> --}}
                            <td class="w-80">
                                @php
                                    $why_3 = unserialize($data2->why_3);
                                @endphp
                                
                                @if(is_array($why_3))
                                    @foreach($why_3 as $value)
                                        {{ htmlspecialchars($value) }}
                                    @endforeach
                                @elseif(is_string($why_3))
                                    {{ htmlspecialchars($why_3) }}
                                @else
                                    Not Applicable
                                @endif
                                  </td>
                        </tr>
                        <tr>
                            <th class="w-20">Why 4</th>
                            {{-- <td class="w-80">@if($data2->why_4){{ $data2->why_4 }}@else Not Applicable @endif</td> --}}
                            <td class="w-80">
                                @php
                                    $why_4 = unserialize($data2->why_4);
                                @endphp
                                
                                @if(is_array($why_4))
                                    @foreach($why_4 as $value)
                                        {{ htmlspecialchars($value) }}
                                    @endforeach
                                @elseif(is_string($why_4))
                                    {{ htmlspecialchars($why_4) }}
                                @else
                                    Not Applicable
                                @endif
                                  </td>
                            <th class="w-20">Why5</th>
                            {{-- <td class="w-80">@if($data2->why_4){{ $data2->why_4 }}@else Not Applicable @endif</td> --}}
                            <td class="w-80">
                                @php
                                    $why_5 = unserialize($data2->why_5);
                                @endphp
                                
                                @if(is_array($why_5))
                                    @foreach($why_5 as $value)
                                        {{ htmlspecialchars($value) }}
                                    @endforeach
                                @elseif(is_string($why_5))
                                    {{ htmlspecialchars($why_5) }}
                                @else
                                    Not Applicable
                                @endif
                                  </td>
                        </tr>
                        <tr>
                            <th class="w-20">Root Cause :	</th>
                            <td class="w-80">@if($data2->why_root_cause){{ $data2->why_root_cause }}@else Not Applicable @endif</td>
                          
                        </tr> 
                 </table>
                 <div class="block-head">
                    Is/Is Not Analysis
                </div>
                <table>
                    - <tr>
                        <th class="w-20">What Will Be</th>
                        <td class="w-80">@if($data2->what_will_be){{ $data2->what_will_be }}@else Not Applicable @endif</td>
                        <th class="w-20">What Will Not Be </th>
                        <td class="w-80">@if($data2->what_will_not_be){{ $data2->what_will_not_be }}@else Not Applicable @endif</td>
                        <th class="w-20">What Will Rationale </th>
                        <td class="w-80">@if($data2->what_rationable){{ $data2->what_rationable }}@else Not Applicable @endif</td>
                    </tr>
                       <tr>
                        <th class="w-20">Where Will Be</th>
                        <td class="w-80">@if($data2->where_will_be){{ $data2->where_will_be }}@else Not Applicable @endif</td>
                        <th class="w-20">Where Will Not Be </th>
                        <td class="w-80">@if($data2->where_will_not_be){{ $data2->where_will_not_be }}@else Not Applicable @endif</td>
                        <th class="w-20">Where Will Rationale </th>
                        <td class="w-80">@if($data2->where_rationable){{ $data2->where_rationable }}@else Not Applicable @endif</td>
                    </tr>
                    <tr>
                        <th class="w-20">When Will Be</th>
                        <td class="w-80">@if($data2->when_will_be){{ $data2->when_will_be }}@else Not Applicable @endif</td>
                        <th class="w-20">When Will Not Be </th>
                        <td class="w-80">@if($data2->when_will_not_be){{ $data2->when_will_not_be }}@else Not Applicable @endif</td>
                        <th class="w-20">When Will Rationale </th>
                        <td class="w-80">@if($data2->when_rationable){{ $data2->when_rationable }}@else Not Applicable @endif</td>
                    </tr>
                    <tr>
                        <th class="w-20">Coverage Will Be</th>
                        <td class="w-80">@if($data2->coverage_will_be){{ $data2->coverage_will_be }}@else Not Applicable @endif</td>
                        <th class="w-20">Coverage Will Not Be </th>
                        <td class="w-80">@if($data2->coverage_will_not_be){{ $data2->coverage_will_not_be }}@else Not Applicable @endif</td>
                        <th class="w-20">Coverage Will Rationale </th>
                        <td class="w-80">@if($data2->coverage_rationable){{ $data2->coverage_rationable }}@else Not Applicable @endif</td>
                      
                    </tr> 
                    <tr>
                        <th class="w-20">Who Will Be</th>
                        <td class="w-80">@if($data2->who_will_be){{ $data2->who_will_be }}@else Not Applicable @endif</td>
                        <th class="w-20">Who Will Not Be </th>
                        <td class="w-80">@if($data2->who_will_not_be){{ $data2->who_will_not_be }}@else Not Applicable @endif</td>
                        <th class="w-20">Who Will Rationale </th>
                        <td class="w-80">@if($data2->who_rationable){{ $data2->who_rationable }}@else Not Applicable @endif</td>
                      
                    </tr> 
                </table>        
                                    </div>
                                </div>
                                <div class="block">
                                    <div class="block-head">
                                        QA Review
                                    </div>
                    
                                        <table>
                                        
                                            <tr>
                                                <th class="w-20">Final Comments</th>
                                                <td class="w-80">@if($data2->cft_comments_new){{ $data2->cft_comments_new }}@else Not Applicable @endif</td>
                                            </tr>
                                        
                                        </table>
                                        <div class="border-table">
                                            <div class="block-head">
                                                Final Attachment
                    
                                            </div>
                                            <table>
                        
                                                <tr class="table_bg">
                                                    <th class="w-20">S.N.</th>
                                                    <th class="w-60">Attachmen</th>
                                                </tr>
                                                    @if($data2->cft_attchament_new)
                                                    @foreach(json_decode($data2->cft_attchament_new) as $key => $file)
                                                        <tr>
                                                            <td class="w-20">{{ $key + 1 }}</td>
                                                            <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                        </tr>
                                                    @endforeach
                                                    @else
                                                <tr>
                                                    <td class="w-20">1</td>
                                                    <td class="w-20">Not Applicable</td>
                                                </tr>
                                                @endif
                        
                                            </table>
                                        </div>
                                    </div>
                                
                                    
                                    <div class="block">
                                        <div class="block-head">
                                            Activity log
                                        </div>
                                        <table>
                    
                                        <tr>
                                            <th class="w-20">Acknowledge By</th>
                                            <td class="w-30">{{ $data2->acknowledge_by }}</td>
                                            <th class="w-20">Acknowledge By</th>
                                            <td class="w-30">{{ Helpers::getdateFormat($data2->acknowledge_on) }}</td>
                                        </tr>
                                        <tr>
                                            <th class="w-20">Submited By</th>
                                            <td class="w-30">{{ $data2->submitted_by }}</td>
                                            <th class="w-20">Submited On</th>
                                            <td class="w-30">{{ Helpers::getdateFormat($data2->submitted_on) }}</td>
                                        </tr>
                                        <tr>
                                            <th class="w-20">QA Review Completed By</th>
                                            <td class="w-30">{{ $data2->qA_review_complete_by }}</td>
                                            <th class="w-20">QA Review Completed On</th>
                                            <td class="w-30">{{ Helpers::getdateFormat($data2->qA_review_complete_on) }}</td>
                                        </tr>
                                        {{-- <tr>
                                            <th class="w-20">Audit preparation completed by</th>
                                            <td class="w-30">{{ $data2->audit_preparation_completed_by }}</td>
                                            <th class="w-20">Audit preparation completed On</th>
                                            <td class="w-30">{{ Helpers::getdateFormat($data2->audit_preparation_completed_on) }}</td>
                                        </tr> --}}
                                        <tr>
                                            <th class="w-20">Cancelled By</th>
                                            <td class="w-30">{{ $data2->cancelled_by }}</td>
                                            <th class="w-20">Cancelled On</th>
                                            <td class="w-30">{{ Helpers::getdateFormat($data2->cancelled_on) }}</td>
                                        </tr>
                                        
                                    </table>
                            </div>
                            @else
                            <div>
                                
                                <h4>There is no Root Cause Analysis Child</h4>
                            </div>
                                @endif    
                                 <div class="block-child">
                                            Action Item
                                      </div> 
                            @if(!empty($data4))   
                                <div class="inner-block">
                                    <div class="content-table">
                                        <div class="block">
                                            <div class="block-head">
                                                General Information
                                            </div>
                                            <table>
                                                <tr>
                                                    <th class="w-20">Record Number</th>
                                                    <td class="w-30">@if($data4->record){{  str_pad($data4->record, 4, '0', STR_PAD_LEFT) }} @else Not Applicable @endif</td>
                                                    <th class="w-20">Site/Location Code</th>
                                                    <td class="w-30">@if($data4->division_id){{  Helpers::getDivisionName($data4->division_id) }} @else Not Applicable @endif</td>
                                                </tr>
                            
                                                <tr>  {{ $data4->created_at }} added by {{ $data4->originator }}
                                                    <th class="w-20">Initiator</th>
                                                    <td class="w-30">{{ Helpers::getInitiatorName($data4->initiator_id) }}</td>
                                                    <th class="w-20">Date of Initiation</th>
                                                    <td class="w-30">{{ Helpers::getdateFormat($data4->created_at) }}</td>
                                                </tr>
                                                
                                                <tr>
                                                   <th class="w-20">Assigned To</th>
                                                    <td class="w-30">@if($data4->assign_to){{ Helpers::getInitiatorName($data4->assign_to) }} @else Not Applicable @endif</td>
                                                    <th class="w-20">Due Date</th>
                                                    <td class="w-80"> @if($data4->due_date){{ Helpers::getdateFormat($data4->due_date) }} @else Not Applicable @endif</td>
                                                   
                                                </tr>
                                                 <tr>
                                                    <th class="w-20">Short Description</th>
                                                    <td class="w-80">@if($data4->short_description){{ $data4->short_description }}@else Not Applicable @endif</td>
                                                   
                            
                                                </tr>
                                                <tr>
                                                        <th class="w-20">Action Item Related Records</th>
                                                        <td class="w-80">@if($data4->Reference_Recores1){{ Helpers::getDivisionName($data4->division_id) }}/AI/{{ date('Y') }}/{{ Helpers::recordFormat($data4->record) }}@else Not Applicable @endif</td>
                                                      
                                               </tr>
                                               <tr>
                                                    <th class="w-20">HOD Persons</th>
                                                    <td class="w-80">@if($data4->hod_preson)  @foreach(explode(',',$data4->hod_preson) as $hod) {{  Helpers::getInitiatorName($hod)  }} ,  @endforeach @else Not Applicable @endif</td>
                                                </tr>
                                              
                                               <tr>
                                                    <th class="w-20">Description</th>
                                                    <td class="w-80">@if($data4->description){{ $data4->description }}@else Not Applicable @endif</td>
                            
                                                </tr>
                                               
                                                <tr>
                                                    <th class="w-20">Responsible Department</th>
                                                    <td class="w-80">@if($data4->departments){{ $data4->departments }}@else Not Applicable @endif</td>
                            
                                                </tr>
                            
                                                
                                
                                                   <div class="block-head">
                                                   File Attachments
                                                </div>
                                                  <div class="border-table">
                                                    <table>
                                                        <tr class="table_bg">
                                                            <th class="w-20">S.N.</th>
                                                            <th class="w-60">File </th>
                                                        </tr>
                                                            @if($data4->file_attach)
                                                            @foreach(json_decode($data4->file_attach) as $key => $file)
                                                                <tr>
                                                                    <td class="w-20">{{ $key + 1 }}</td>
                                                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                                </tr>
                                                            @endforeach
                                                            @else
                                                            <tr>
                                                                <td class="w-20">1</td>
                                                                <td class="w-20">Not Applicable</td>
                                                            </tr>
                                                        @endif
                            
                                                    </table>
                                                  </div>
                                            </table>
                                        </div>
                            
                                        <!-- <div class="block">
                                            <div class="head">
                            
                                                <table>
                                                    <tr>
                                                        <th class="w-20">CAPA Related Records</th>
                                                        <td class="w-80">@if($data4->capa_related_record){{ $data4->capa_related_record }}@else Not Applicable @endif</td>
                                                    </tr>
                                                
                            
                                                    </table>
                                                  </div>
                                                </table>
                                               
                                            </div>
                                        </div> -->
                            
                                              <div class="block-head">
                                                Post Completion
                                                </div>
                                                <table>
                                                 <tr>
                                                    <th class="w-20">Action Taken</th>
                                                    <td class="w-80">@if($data4->action_taken){{ $data4->action_taken }}@else Not Applicable @endif</td>
                                                   
                                                 </tr>
                                               <tr>
                                                    <th class="w-20">Action Start Date</th>
                                                    <td class="w-80">@if($data4->start_date){{ Helpers::getdateFormat($data4->start_date) }}@else Not Applicable @endif</td>
                                                    <th class="w-20">Actual End Date</th>
                                                    <td class="w-80">@if($data4->end_date){{ Helpers::getdateFormat($data4->end_date) }}@else Not Applicable @endif</td>
                                               </tr>
                                               <tr>
                                                    <th class="w-20">Comments</th>
                                                    <td class="w-80">@if($data4->comments){{ $data4->comments }}@else Not Applicable @endif</td>
                                                   
                                               </tr>
                                               </table>
                                                 <div class="block-head">
                                                     Action Approval
                                                </div>
                                                <table>
                                               <tr>
                                                    <th class="w-20">QA Review Comments</th>
                                                    <td class="w-80">@if($data4->qa_comments){{ $data4->qa_comments }}@else Not Applicable @endif</td>
                                                   
                                               </tr>
                                           
                                               </table>
                                        
                                                
                                                
                                              <div class="block-head">
                                                Extension Justification
                                              </div>
                                                <table>
                                                 <tr>
                                                    <th class="w-20">Due Date Extension Justification</th>
                                                    <td class="w-80">@if($data4->due_date_extension){{ $data4->due_date_extension }}@else Not Applicable @endif</td>
                                                   
                                                  </tr>
                                               
                                               </table>
                                            
                                                
                            
                            
                                        <div class="block">
                                            <div class="block-head">
                                                Activity Log
                                            </div>
                                            <table>
                                                <tr>
                                                    <th class="w-20">Submitted By
                                                    </th>
                                                    <td class="w-30">{{ $data4->submitted_by }}</td>
                                                    <th class="w-20">
                                                    Submitted On</th>
                                                    <td class="w-30">{{ $data4->submitted_on }}</td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Cancelled By
                                                    </th>
                                                    <td class="w-30">{{ $data4->cancelled_by }}</td>
                                                    <th class="w-20">
                                                    Cancelled On</th>
                                                    <td class="w-30">{{ $data4->cancelled_on }}</td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">More information required By
                                                    </th>
                                                    <td class="w-30">{{ $data4->more_information_required_by }}</td>
                                                    <th class="w-20">
                                                    More information required On</th>
                                                    <td class="w-30">{{ $data4->more_information_required_on }}</td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Completed By
                                                    </th>
                                                    <td class="w-30">{{ $data4->completed_by }}</td>
                                                    <th class="w-20">
                                                    Completed On</th>
                                                    <td class="w-30">{{ $data4->completed_on }}</td>
                                                </tr>
                                               
                                            </table>
                                        </div>
                                    </div>
                                </div>  
                                @else
                                    <div>
                                        <h4>There is no Action Item Child</h4>
                            @endif        
                                    </div>
                                
                                <div class="block-child">
                                    EffectivenessCheck
                              </div> 
                            @if(!empty($data5))   

                                <div class="inner-block">
                                    <div class="content-table">
                                        <div class="block">
                                            <div class="block-head">
                                                General Information
                                            </div>
                                            <table>
                                                <tr>
                                                    <th class="w-20">Record Number</th>
                                                    <td class="w-30">@if($data5->record){{  str_pad($data5->record, 4, '0', STR_PAD_LEFT) }} @else Not Applicable @endif</td>
                                                    <th class="w-20">Site/Location Code</th>
                                                    <td class="w-30">@if($data5->division_id){{   Helpers::getDivisionName($data5->division_id) }} @else Not Applicable @endif</td>
                                                </tr>
                            
                                                <tr>  {{ $data5->created_at }} added by {{ $data5->originator }}
                                                    <th class="w-20">Initiator</th>
                                                    <td class="w-30">{{ Helpers::getInitiatorName($data5->initiator_id) }}</td>
                                                    <th class="w-20">Date of Initiation</th>
                                                    <td class="w-30">{{ Helpers::getdateFormat($data5->created_at) }}</td>
                                                </tr>
                                                
                                                <tr>
                                                   <th class="w-20">Assigned To</th>
                                                    <td class="w-30">@if($data5->assign_to){{ Helpers::getInitiatorName($data5->assign_to) }} @else Not Applicable @endif</td>
                                                    <th class="w-20">Due Date</th>
                                                    <td class="w-80"> @if($data5->due_date){{ Helpers::getdateFormat($data5->due_date) }} @else Not Applicable @endif</td>
                                                   
                                                </tr>
                                                 <tr>
                                                    <th class="w-20">Short Description</th>
                                                    <td class="w-80">@if($data5->short_description){{ $data5->short_description }}@else Not Applicable @endif</td>
                                                </tr>
                                                </table>
                                           
                                                <div class="block-head">
                                                   Effectiveness Planning Information
                                               </div>
                                               <table>
                                                
                                               <tr>
                                                    <th class="w-20">Effectiveness check Plan</th>
                                                    <td class="w-80">@if($data5->Effectiveness_check_Plan){{ $data5->Effectiveness_check_Plan }}@else Not Applicable @endif</td>
                                               </tr>
                                               </table>
                                                <div class="block-head">
                                                   Attachments
                                                </div>
                                                  <div class="border-table">
                                                    <table>
                                                        <tr class="table_bg">
                                                            <th class="w-20">S.N.</th>
                                                            <th class="w-60">File </th>
                                                        </tr>
                                                            @if($data5->Attachments)
                                                            @foreach(json_decode($data5->Attachments) as $key => $file)
                                                                <tr>
                                                                    <td class="w-20">{{ $key + 1 }}</td>
                                                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                                </tr>
                                                            @endforeach
                                                            @else
                                                            <tr>
                                                                <td class="w-20">1</td>
                                                                <td class="w-20">Not Applicable</td>
                                                            </tr>
                                                        @endif
                            
                                                    </table>
                                                  </div>
                                            </table>
                                        </div>
                            
                            
                                         <div class="block-head">
                                              Effectiveness Summary
                                         </div>
                                             <table>
                                                 <tr>
                                                    <th class="w-20">Effectiveness Summary</th>
                                                    <td class="w-80">@if($data5->effect_summary){{ $data5->effect_summary }}@else Not Applicable @endif</td>
                                                 </tr>
                                              </table>
                                          <div class="block-head">
                                                 Effectiveness Check Results
                                            </div>
                                                <table>
                                                 <tr>
                                                    <th class="w-20">Effectiveness Results</th>
                                                    <td class="w-80">@if($data5->Effectiveness_Results){{ $data5->Effectiveness_Results }}@else Not Applicable @endif</td>
                                                   
                                                  </tr>
                                              </table>
                                                <div class="block-head">
                                                   Attachments
                                                </div>
                                                  <div class="border-table">
                                                    <table>
                                                        <tr class="table_bg">
                                                            <th class="w-20">S.N.</th>
                                                            <th class="w-60">File </th>
                                                        </tr>
                                                            @if($data5->Attachments)
                                                            @foreach(json_decode($data5->Attachments) as $key => $file)
                                                                <tr>
                                                                    <td class="w-20">{{ $key + 1 }}</td>
                                                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                                </tr>
                                                            @endforeach
                                                            @else
                                                            <tr>
                                                                <td class="w-20">1</td>
                                                                <td class="w-20">Not Applicable</td>
                                                            </tr>
                                                        @endif
                            
                                                    </table>
                                                  </div>
                                           
                                                <div class="block-head">
                                                   Reopen
                                                </div>
                                                <table>
                                                 <tr>
                                                    <th class="w-20">Addendum Comments</th>
                                                    <td class="w-80">@if($data5->Addendum_Comments){{ $data5->Addendum_Comments }}@else Not Applicable @endif</td>
                                                   
                                                  </tr>
                                              </table>
                                                <div class="block-head">
                                                Addendum Attachment
                                                </div>
                                                  <div class="border-table">
                                                    <table>
                                                        <tr class="table_bg">
                                                            <th class="w-20">S.N.</th>
                                                            <th class="w-60">File </th>
                                                        </tr>
                                                            @if($data5->Addendum_Attachment)
                                                            @foreach(json_decode($data5->Addendum_Attachment) as $key => $file)
                                                                <tr>
                                                                    <td class="w-20">{{ $key + 1 }}</td>
                                                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                                </tr>
                                                            @endforeach
                                                            @else
                                                            <tr>
                                                                <td class="w-20">1</td>
                                                                <td class="w-20">Not Applicable</td>
                                                            </tr>
                                                        @endif
                            
                                                    </table>
                                                  </div>
                            
                                                  <div class="block-head">
                                                  Reference Info comments
                                                </div>
                                                <table>
                                                 <tr>
                                                    <th class="w-20">Comments</th>
                                                    <td class="w-80">@if($data5->Comments){{ $data5->Comments }}@else Not Applicable @endif</td>
                                                   
                                                  </tr>
                                              </table>
                                                <div class="block-head">
                                                   Attachment
                                                </div>
                                                  <div class="border-table">
                                                    <table>
                                                        <tr class="table_bg">
                                                            <th class="w-20">S.N.</th>
                                                            <th class="w-60">File </th>
                                                        </tr>
                                                            @if($data5->Attachment)
                                                            @foreach(json_decode($data5->Attachment) as $key => $file)
                                                                <tr>
                                                                    <td class="w-20">{{ $key + 1 }}</td>
                                                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                                </tr>
                                                            @endforeach
                                                            @else
                                                            <tr>
                                                                <td class="w-20">1</td>
                                                                <td class="w-20">Not Applicable</td>
                                                            </tr>
                                                        @endif
                            
                                                    </table>
                                                  </div>
                                                  <div class="block-head">
                                                  Reference Records
                                                </div>
                                                  <div class="border-table">
                                                    <table>
                                                        <tr class="table_bg">
                                                            <th class="w-20">S.N.</th>
                                                            <th class="w-60">File </th>
                                                        </tr>
                                                            @if($data5->refer_record)
                                                            @foreach(json_decode($data5->refer_record) as $key => $file)
                                                                <tr>
                                                                    <td class="w-20">{{ $key + 1 }}</td>
                                                                    <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                                </tr>
                                                            @endforeach
                                                            @else
                                                            <tr>
                                                                <td class="w-20">1</td>
                                                                <td class="w-20">Not Applicable</td>
                                                            </tr>
                                                        @endif
                            
                                                    </table>
                                                  </div>
                                        <div class="block">
                                            <div class="block-head">
                                            Activity Log
                                            </div>
                                            <table>
                                                <tr>
                                                    <th class="w-20">Submit by
                                                    </th>
                                                    <td class="w-30">{{ $data5->submit_by }}</td>
                                                    <th class="w-20">
                                                    Submit On</th>
                                                    <td class="w-30">{{ $data5->submit_on }}</td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Not Effective By
                                                    </th>
                                                    <td class="w-30">{{ $data5->not_effective_by }}</td>
                                                    <th class="w-20">
                                                    Not Effective On</th>
                                                    <td class="w-30">{{ $data5->not_effective_on }}</td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Effective by
                                                    </th>
                                                    <td class="w-30">{{ $data5->effective_by }}</td>
                                                    <th class="w-20">
                                                    Effective On</th>
                                                    <td class="w-30">{{ $data5->effective_on }}</td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Not Effective Approval Complete By
                                                    </th>
                                                    <td class="w-30">{{ $data5->not_effective_approval_complete_by }}</td>
                                                    <th class="w-20">
                                                    Not Effective Approval Complete On</th>
                                                    <td class="w-30">{{ $data5->not_effective_approval_complete_on }}</td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Effective Approval Complete By
                                                    </th>
                                                    <td class="w-30">{{ $data5->effective_approval_complete_by }}</td>
                                                    <th class="w-20">
                                                    Effective Approval Complete On</th>
                                                    <td class="w-30">{{ $data5->effective_approval_complete_on }}</td>
                                                </tr>
                                               
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                @else
                                <div>
                                    
                                    <h4>There is no EffectivenessCheck Child</h4>
                                </div>
                            @endif
                            <div class="block-child">
                              Change Control
                          </div> 
                            @if(!empty($data6))
                            <div class="inner-block">
                                <div class="content-table">
                                    <div class="block">
                                        <div class="block-head">
                                            General Information
                                        </div>
                                        <table>
                                            <tr>  On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}
                                                <th class="w-20">Initiator</th>
                                                <td class="w-30">@if($data6->originator){{ $data6->originator }} @else Not Applicable @endif</td>
                                                
                                            </tr>
                                            <tr>
                                                <th class="w-20">Initiator Group</th>
                                                <td class="w-30">@if($data6->Inititator_Group){{ $data6->Inititator_Group }} @else Not Applicable @endif</td>
                                                <th class="w-20">Due Date</th>
                                                <td class="w-30" colspan="3"> @if($data6->due_date){{ $data6->due_date }} @else Not Applicable @endif</td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Assigned To</th>
                                                <td class="w-30">@if($data6->assign_to) {{ Helpers::getInitiatorName($data6->assign_to) }} @else Not Applicable @endif</td>
                                                <th class="w-20">Initiator Group Code</th>
                                                <td class="w-30" colspan="3"> @if($data6->initiator_group_code){{ $data6-> initiator_group_code}} @else Not Applicable @endif</td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">CFT</th>
                                                <td class="w-30">{{ $data6->Microbiology }}</td>
                                                <th class="w-20">CFT Person</th>
                                                <td class="w-30">{{ $data6->Microbiology_Person }}</td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Severity Level</th>
                                                <td class="w-30">@if($data6->severity_level1){{ $data6-> severity_level1}} @else Not Applicable @endif</td>
                                                <th class="w-20">Initiated Through</th>
                                                <td class="w-30" colspan="3"> @if($data6->initiated_through){{ $data6->initiated_through }} @else Not Applicable @endif</td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Others</th>
                                                <td class="w-30">@if($data6->initiated_through_req){{ $data6->initiated_through_req }} @else Not Applicable @endif</td>
                                                <th class="w-20">Repeat</th>
                                                <td class="w-30" colspan="3"> @if($data6->repeat){{ $data6-> repeat}} @else Not Applicable @endif</td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Repeat Nature</th>
                                                <td class="w-30">@if($data6->repeat_nature){{ $data6-> repeat_nature}} @else Not Applicable @endif</td>
                                                <th class="w-20">Division Code</th>
                                                <td class="w-30" colspan="3"> @if($data6->div_code){{ $data6->div_code }} @else Not Applicable @endif</td>
                                            </tr>
                                            
                                            <tr>
                                                <th class="w-20">Short Description</th>
                                                <td class="w-80" colspan="3">
                                                    @if($data6->short_description){{ $data6->short_description }}@else Not Applicable @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Nature of Change</th>
                                                <td class="w-30">@if($data6->doc_change){{ $data6->doc_change }}@else Not Applicable @endif</td>
                                                <th class="w-20">If Others</th>
                                                <td class="w-30">@if($data6->If_Others){{ $data6->If_Others }}@else Not Applicable @endif</td>
                                            </tr>
                                        </table>
                                        <div class="border-table">
                                            <div class="block-head">
                                                Initial Attachment
                                            </div>
                                            <table>
                        
                                                <tr class="table_bg">
                                                    <th class="w-20">S.N.</th>
                                                    <th class="w-60">Attachment</th>
                                                </tr>
                                                @if($data->in_attachment)
                                                    @foreach(json_decode($data6->in_attachment) as $key => $file)
                                                    <tr>
                                                        <td class="w-20">{{ $key + 1 }}</td>
                                                        <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                    </tr>
                                                        @endforeach
                                                        @else
                                                    <tr>
                                                        <td class="w-20">1</td>
                                                        <td class="w-20">Not Applicable</td>
                                                    </tr>
                                                @endif
                        
                                            </table>
                                        </div>
                                    </div>
                                    {{-- <div class="block">
                                        <div class="block-head">
                                            Change Details
                                        </div>
                                        <div class="border-table">
                                            <table>
                                                <tr class="table_bg">
                                                    <th class="w-25">Current Document No.</th>
                                                    <th class="w-25">Current Version No.</th>
                                                    <th class="w-25">New Document No.</th>
                                                    <th class="w-25">New Version No.</th>
                                                </tr>
                                                @foreach(unserialize($data6->current_doc_no) as $key => $docdetails)
                                                <tr>
                                                    <td class="w-25">@if($docdetails){{ $docdetails }}@else Not Applicable @endif</td>
                                                    <td class="w-25">{{unserialize($data6->current_version_no)[$key] }}</td>
                                                    <td class="w-25">{{ unserialize($data6->new_doc_no)[$key] }}</td>
                                                    <td class="w-25">{{ unserialize($data6->new_version_no)[$key] }}</td>
                                                </tr>
                                                @endforeach
                                            </table>
                                        </div>
                                        <table>
                                            <tr>
                                                <th class="w-20">Current Practice</th>
                                                <td>
                                                    <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong></div>
                                                    <div>
                                                        @if($data6->current_practice){{ $data6->current_practice }}@else Not Applicable @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Proposed Change</th>
                                                <td>
                                                    <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong></div>
                                                    <div>
                                                        @if($data6->proposed_change){{ $data6->proposed_change }}@else Not Applicable @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Reason For Change</th>
                                                <td>
                                                    <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong></div>
                                                    <div>
                                                        @if($data6->reason_change){{ $data6->reason_change }}@else Not Applicable @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Supervisor Comments</th>
                                                <td>
                                                    <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong></div>
                                                    <div>
                                                        @if($data6->supervisor_comment){{ $data6->supervisor_comment }}@else Not Applicable @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Any Other Comments</th>
                                                <td>
                                                    <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong></div>
                                                    <div>
                                                        @if($data6->other_comment){{ $data6->other_comment }}@else Not Applicable @endif
                                                    </div>
                                                </td>
                                            </tr>
                                        </table>
                                    </div> --}}
                                    <div class="block">
                                        <div class="head">
                                            <div class="block-head">
                                                QA Review
                                            </div>
                                            <table>
                                                <tr>
                                                    <th class="w-20">Type of Change</th>
                                                    <td class="w-80">{{ $data6->type_chnage }}</td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">QA Review Comments</th>
                                                    <td>
                                                        <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong></div>
                                                        <div>
                                                            {{ $data6->qa_comments }}
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Related Records</th>
                                                    <td class="w-80">{{ $data6->related_records }}</td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">QA Attachments</th>
                                                    <td class="w-80">{{ $data6->qa_attachments}}</td>
                                                </tr>
                        
                        
                                            </table>
                                            {{-- <div class="border-table">
                                                <div class="block-head">
                                                    QA Attachments
                                                </div>
                                                <table>
                        
                                                    <tr class="table_bg">
                                                        <th class="w-20">S.N.</th>
                                                        <th class="w-60">Attachment</th>
                                                    </tr>
                                                    @if($data6->qa_head)
                                                        @foreach(json_decode($data6->qa_head) as $key => $file)
                                                        <tr>
                                                            <td class="w-20">{{ $key + 1 }}</td>
                                                            <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                        </tr>
                                                            @endforeach
                                                            @else
                                                        <tr>
                                                            <td class="w-20">1</td>
                                                            <td class="w-20">Not Applicable</td>
                                                        </tr>
                                                    @endif
                        
                                                </table>
                                            </div> --}}
                                        </div>
                                    </div>
                                    <div class="block">
                                        <div class="head">
                                            <div class="block-head">
                                                Evaluation Details
                                            </div>
                                            <table>
                                                <tr>
                                                    <th class="w-20">QA Evaluation Comments</th>
                                                    <td>
                                                        <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                        </div>
                                                        <div>
                                                            {{ $data6->qa_eval_comments }}
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">QA Evaluation Attachments </th>
                                                    <td>
                                                        <div><strong>On {{ Helpers:: getDateFormat($data6->qa_evaluation_attachments) }} added by {{ $data6->qa_evaluation_attachments}}</strong>
                                                        </div>
                                                        <div>
                                                            {{ $data6->qa_evaluation_attachments }}
                                                        </div>
                                                    </td>
                                                </tr>
                        
                        
                                                <tr>
                                                    <th class="w-20">Training Required</th>
                                                    <td class="w-80"> {{ $data6->training_required }}</td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Training Comments</th>
                                                    <td>
                                                        <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                        </div>
                                                        <div>
                                                            {{ $data6->train_comments }}
                                                        </div>
                                                    </td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                   
                                    <div class="block">
                                        <div class="head">
                                            <div class="block-head">
                                              Comments
                                            </div>
                                            <table>
                                            <tr>
                                                <th class="w-20">Comments</th>
                                                <td class="w-30">{{ $data6->cft_comments }}</td>
                                                <th class="w-20">Attachment </th>
                                                <td class="w-30">{{ $data6->cft_attachment }}</td>
                                            </tr>
                                                <tr>
                                                    <th class="w-20">QA Comments</th>
                                                    <td class="w-80">
                                                        <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                        </div>
                                                        <div>
                                                            {{ $data6->qa_comments }}
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">QA Head Designee Comments</th>
                                                    <td class="w-80">
                                                        <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                        </div>
                                                        <div>
                                                            {{ $data6->designee_comments }}
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Warehouse Comments</th>
                                                    <td class="w-80">
                                                        <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                        </div>
                                                        <div>
                                                            {{ $data6->Warehouse_comments }}
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Engineering Comments</th>
                                                    <td class="w-80">
                                                        <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                        </div>
                                                        <div>
                                                            {{ $data6->Engineering_comments }}
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Instrumentation Comments</th>
                                                    <td class="w-80">
                                                        <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                        </div>
                                                        <div>
                                                            {{ $data6->Instrumentation_comments }}
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Validation Comments</th>
                                                    <td class="w-80">
                                                        <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                        </div>
                                                        <div>
                                                            {{ $data6->Validation_comments }}
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Others Comments</th>
                                                    <td class="w-80">
                                                        <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                        </div>
                                                        <div>
                                                            {{ $data6->Others_comments }}
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <th class="w-20">Comments</th>
                                                    <td class="w-80">
                                                        <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                        </div>
                                                        <div>
                                                            {{ $data6->Group_comments }}
                                                        </div>
                                                    </td>
                                                </tr>
                        
                        
                                            </table>
                                            {{-- <div class="border-table"> --}}
                                                {{-- <div class="block-head">
                                                   Attachments
                                                </div> --}}
                                                {{-- <table>
                        
                                                    <tr class="table_bg">
                                                        <th class="w-20">S.N.</th>
                                                        <th class="w-60">Attachment</th>
                                                    </tr>
                                                    @if($data6->group_attachments)
                                                        @foreach(json_decode($data6->group_attachments) as $key => $file)
                                                        <tr>
                                                            <td class="w-20">{{ $key + 1 }}</td>
                                                            <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                        </tr>
                                                            @endforeach
                                                            @else
                                                        <tr>
                                                            <td class="w-20">1</td>
                                                            <td class="w-20">Not Applicable</td>
                                                        </tr>
                                                    @endif
                        
                                                </table> --}}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="block">
                                        <div class="block-head">
                                            Risk Assessment
                                        </div>
                                        <table>
                                            <tr>
                                                <th class="w-20">Risk Identification</th>
                                                <td class="w-80" colspan="3">
                                                    <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong></div>
                                                    <div>
                                                        {{ $data6->risk_identification }}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Severity</th>
                                                <td class="w-30"> {{ $data6->severity }}</td>
                                                <th class="w-20">Occurance</th>
                                                <td class="w-30"> {{ $data6->Occurance }}</td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Detection</th>
                                                <td class="w-30"> {{ $data6->Detection }}</td>
                                                <th class="w-20">RPN</th>
                                                <td class="w-30"> {{ $data6->RPN }}</td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Risk Evaluation</th>
                                                <td class="w-80" colspan="3">
                                                    <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong></div>
                                                    <div>
                                                        {{ $data6->risk_evaluation }}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Mitigation Action</th>
                                                <td class="w-80" colspan="3">
                                                    <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong></div>
                                                    <div>
                                                        {{ $data6->migration_action }}
                                                    </div>
                                                </td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div class="block">
                                        <div class="block-head">
                                            QA Approval Comments
                                        </div>
                                        <table>
                                            <tr>
                                                <th class="w-20">QA Approval Comments</th>
                                                <td class="w-80">
                                                    <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                    </div>
                                                    <div>
                                                        {{ $data6->risk_identification }}
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Training Feedback</th>
                                                <td class="w-80">
                                                    <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                    </div>
                                                    <div>
                                                        {{ $data6->feedback }}
                                                    </div>
                                                </td>
                                            </tr>
                        
                                        </table>
                                        {{-- <div class="border-table">
                                            <div class="block-head">
                                                Training Attachments
                                            </div>
                                            <table>
                        
                                                <tr class="table_bg">
                                                    <th class="w-20">S.N.</th>
                                                    <th class="w-60">Attachment</th>
                                                </tr>
                                                @if($data6->tran_attach)
                                                    @foreach(json_decode($data6->tran_attach) as $key => $file)
                                                    <tr>
                                                        <td class="w-20">{{ $key + 1 }}</td>
                                                        <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                    </tr>
                                                        @endforeach
                                                        @else
                                                    <tr>
                                                        <td class="w-20">1</td>
                                                        <td class="w-20">Not Applicable</td>
                                                    </tr>
                                                @endif
                        
                                            </table>
                                        </div> --}}
                                    </div>
                                    <div class="block">
                                        <div class="block-head">
                                        Change Closure
                                        </div>
                                        <table>
                                            <!-- <tr>
                                                <th class="w-20">Affected Documents+</th>
                                                <td class="w-80">
                                                    <div><strong>On {{ Helpers:: getDateFormat($data6->created_at) }} added by {{ $data6->originator }}</strong>
                                                    </div>
                                                    <div>
                                                        {{ $data6->risk_identification }}
                                                    </div>
                                                </td>
                                            </tr> -->
                                            <tr>
                                                <th class="w-20">QA Closure Comments</th>
                                                <td class="w-30"> {{ $data6->qa_closure_comments }}</td>
                                                <th class="w-20">List Of Attachments</th>
                                                <td class="w-30"> {{ $data6->list_of_attachment }}</td>
                                            </tr>
                                            
                        
                                        </table>
                                        <!-- <div class="border-table">
                                            <div class="block-head">
                                                Training Attachments
                                            </div> -->
                                            {{-- <table>
                        
                                                <tr class="table_bg">
                                                    <th class="w-20">S.N.</th>
                                                    <th class="w-60">Attachment</th>
                                                </tr>
                                                @if($data6->tran_attach)
                                                    @foreach(json_decode($data6->tran_attach) as $key => $file)
                                                    <tr>
                                                        <td class="w-20">{{ $key + 1 }}</td>
                                                        <td class="w-20"><a href="{{ asset('upload/' . $file) }}" target="_blank"><b>{{ $file }}</b></a> </td>
                                                    </tr>
                                                        @endforeach
                                                        @else
                                                    <tr>
                                                        <td class="w-20">1</td>
                                                        <td class="w-20">Not Applicable</td>
                                                    </tr>
                                                @endif
                        
                                            </table>
                                        </div>
                                    </div> --}}
                                    
                        
                        
                                     <div class="block">
                                        <div class="block-head">
                                            Activity Log
                                        </div>
                                        <table>
                                            <tr>
                                                <th class="w-20">Submitted By</th>
                                                <td class="w-30">
                                                @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('stage_id', 2)
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->user_name }}</div>
                                                @endforeach</td>
                        
                                                <th class="w-20">Submitted On</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('stage_id', 2)
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->created_at }}</div>
                                                @endforeach
                                                </td>
                                            </tr>
                                            
                                            <tr>
                                                <th class="w-20">Cancelled By</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('stage_id', 0)
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->user_name }}</div>
                                                @endforeach
                                                </td>
                                                <th class="w-20">Cancelled On</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('stage_id', 0)
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->created_at }}</div>
                                                @endforeach
                                                </td>
                                            </tr>
                                            {{-- <tr>
                                                <th class="w-20">More Information Required By</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('status', 'More-info Required')
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->user_name }}</div>
                                                @endforeach
                                                </td>
                                                <th class="w-20">More Information Required On</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('status', 'More-info Required')
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->created_at }}</div>
                                                @endforeach
                                                </td>
                                            </tr> --}}
                                            <tr>
                                                <th class="w-20">HOD Review Complete By</th>
                                                <td class="w-30"> @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('stage_id', 3)
                                                        ->get();
                                                    @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->user_name }}</div>
                                                @endforeach </td>
                                                <th class="w-20">HOD Review Complete On</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('stage_id', 3)
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->created_at }}</div>
                                                @endforeach
                                                </td>
                                            </tr>
                                            {{-- <tr>
                                                <th class="w-20">More Information Req. By</th>
                                                <td class="w-30">Piyush Sahu</td>
                                                <th class="w-20">More Information Req. On</th>
                                                <td class="w-30">12-12-2203</td>
                                            </tr> --}}
                                            <tr>
                                                <th class="w-20">Send to CFT/SME/QA Review By</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id',$data6->id)
                                                        ->where('stage_id', 4)
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->user_name }}</div>
                                                @endforeach
                                                </td>
                                                <th class="w-20">Send to CFT/SME/QA Review On</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('stage_id', 4)
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->created_at }}</div>
                                                @endforeach
                                                </td>
                                            </tr>
                                            <!-- <tr>
                                                <th class="w-20">More Info Req. By</th>
                                                <td class="w-30">Piyush Sahu</td>
                                                <th class="w-20">More Info Req. On</th>
                                                <td class="w-30">12-12-2203</td>
                                            </tr> -->
                                            <tr>
                                                <th class="w-20">CFT/SME/QA Review Not required By</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('stage_id', 6)
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->user_name }}</div>
                                                @endforeach
                                                </td>
                                                <th class="w-20">CFT/SME/QA Review Not required On</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('stage_id', 6)
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->created_at }}</div>
                                                @endforeach
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Review Completed By</th>
                                                <td class="w-30">
                                                    @php
                                                        $submit = DB::table('c_c_stage_histories')
                                                              ->where('type', 'Change-Control')
                                                              ->where('doc_id', $data6->id)
                                                              ->where('stage_id', 7)
                                                              ->get();
                                                    @endphp
                                                    @foreach ($submit as $data6)
                                                        <div class="static">{{ $data6->user_name }}</div>
                                                    @endforeach 
                                                </td>
                                                <th class="w-20">Review Completed On</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('stage_id', 7)
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->created_at }}</div>
                                                @endforeach
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="w-20">Implemented By</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('stage_id', 9)
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->user_name }}</div>
                                                @endforeach
                                                </td>
                                                <th class="w-20">Implemented On</th>
                                                <td class="w-30">
                                                    @php
                                                    $submit = DB::table('c_c_stage_histories')
                                                        ->where('type', 'Change-Control')
                                                        ->where('doc_id', $data6->id)
                                                        ->where('stage_id', 9)
                                                        ->get();
                                                @endphp
                                                @foreach ($submit as $data6)
                                                    <div class="static">{{ $data6->created_at }}</div>
                                                @endforeach
                                                </td>
                                            </tr>
                                            {{-- <tr>
                                                <th class="w-20">Change Implemented By</th>
                                                <td class="w-30">Piyush Sahu</td>
                                                <th class="w-20">Change Implemented On</th>
                                                <td class="w-30">12-12-2203</td>
                                            </tr> --}}
                                            <!-- <tr>
                                                <th class="w-20">QA More Information Required By</th>
                                                <td class="w-30">Piyush Sahu</td>
                                                <th class="w-20">QA More Information Required On</th>
                                                <td class="w-30">12-12-2203</td>
                                            </tr> -->
                                            {{-- <tr>
                                                <th class="w-20">QA Final Review Completed By</th>
                                                <td class="w-30">Piyush Sahu</td>
                                                <th class="w-20">QA Final Review Completed On</th>
                                                <td class="w-30">12-12-2203</td>
                                            </tr> --}}
                                        </table>
                                    </div> 
                                </div>
                            </div>
                             
                             @else
                               <div>
                                
                                <h4>There is no Change Control Child</h4>
                               </div>
                            @endif




    <footer>
        <table>
            <tr>
                <td class="w-30">
                    <strong>Printed On :</strong> {{ date('d-M-Y') }}
                </td>
                <td class="w-40">
                    <strong>Printed By :</strong> {{ Auth::user()->name }}
                </td>
                {{-- <td class="w-30">
                    <strong>Page :</strong> 1 of 1
                </td> --}}
            </tr>
        </table>
       
    </footer>

</body>

</html>
