@include('frontend.layout.header')
@yield('container')
@include('frontend.layout.footer')
